import numpy as np
from matplotlib import pyplot as plt

def ShowChartForModel(ModelPath):
	ModelPath = '../MODEL/' + ModelPath + '/'

	#Load Model MSQE learning curves, remove first couple values to make graph shape nicer
	TRAIN = np.load(ModelPath + 'TCost.npy')[2:]
	CROSS = np.load(ModelPath + 'CCost.npy')[2:]

	#Scale MSQE to RMSQE of 96 pixels distance
	TRAIN = ((TRAIN ** 0.5) * 96.0).reshape((TRAIN.shape[0],1))
	CROSS = ((CROSS ** 0.5) * 96.0).reshape((TRAIN.shape[0],1))

	#Create Epoc Counter for Domain of Errors Graph 
	EPOC = list(range(TRAIN.shape[0]))

	#print minimum cross validation score reached/saved
	print ModelPath + ' Min CrossVal RMSQE: ' + str(np.min(CROSS))

	#plot chart
	plt.plot(EPOC,TRAIN, marker='^',c='b',lw='1',ls='none',label='Train')
	plt.plot(EPOC,CROSS, marker='o', c='g', lw='1',ls='none',label='XVal')

	plt.title('Learning Curves')
	plt.legend()
	plt.ylabel('RMSQE')
	plt.xlabel('~EPOC')
	plt.show()
	return np.min(CROSS)


min1 = ShowChartForModel('A_SIMPLE')
min2 = ShowChartForModel('B_SIMPLE')
minF = (((min1 * 8.0) + (min2 * 22.0))/30.0)
print 'Avg Min CrossVal RMSQE: ' + str(minF)
