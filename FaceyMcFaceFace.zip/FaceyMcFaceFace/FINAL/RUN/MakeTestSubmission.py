import numpy as np

print 'Loading Results'
yh = np.load('../DATA/TEST_YHAT.npy').astype(np.int)
idref = np.load('../DATA/IDREF.npy')

#WRITE OUT SUBMISSION RESULTS CSV FILE FROM YHAT RESULTS
counter = 1 
print 'Opening File'
f = open('../DATA/submission.csv','w')

print 'Writing File'
f.write('RowId,Location\n')
for i in range(len(idref)):
        image = idref[i][0] - 1 
        feat = idref[i][1]
        location = int(yh[image][feat])
        stringy = str(counter) + ',' + str(location) + '\n'
        f.write(stringy)
        counter = counter + 1 
f.close()

print 'Finished'

