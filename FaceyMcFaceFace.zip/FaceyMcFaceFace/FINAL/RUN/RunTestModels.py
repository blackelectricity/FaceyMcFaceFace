import sys
sys.path.insert(0,'../UTIL')
import ImgUtil as IU
import NormUtil as NU
from TFlowModel import Model
import RunHelper as RH 
import numpy as np

#DEFINE MODEL
print 'running part A'
model = Model({
	"X"  : '../DATA/F_Clean_Test_X_SHRINK.npy',
	"Xwidth" : 48,
	"Xheight" : 48,
	"Ylength" : 8,
	"SaveDirectory": '../MODEL/A/',
	"dimensionAfterConv": 57600,
	"convLayers" : [[18,18,1,100]],
	"fullLayers" : [[57600, 64],[64, 8]]
})
Y_A = model.LoadAndRunModel()

print 'running part B'
model = Model({
	"X"  : '../DATA/F_Clean_Test_X_SHRINK.npy',
	"Xwidth" : 48,
	"Xheight" : 48,
	"Ylength" : 22,
	"SaveDirectory": '../MODEL/B/',
	"dimensionAfterConv": 57600,
	"convLayers" : [[18,18,1,100]],
	"fullLayers" : [[57600, 64],[64, 22]]
})
Y_B = model.LoadAndRunModel()
	
print 'merging features'
Y = RH.MergeFeatures(Y_A, Y_B)

print 'preview result'
for inx in range(min(Y.shape[0], 3)):
	IU.ShowImageWithFeatureArray(model.X[inx], 48,48, Y[inx])

print 'scaling result for saving'
Y = NU.ScaleIntHard(Y)
np.save('../DATA/TEST_YHAT.npy', Y)

print 'done'
	
