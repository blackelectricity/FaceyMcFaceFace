import numpy as np

def MergeFeatures(A,B):
	y = np.zeros((A.shape[0], 30))
	EyesNoseLipCols = [0,1,2,3,20,21,28,29] 
	RemainderCols = [4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,22,23,24,25,26,27]
	for pos,index in enumerate(EyesNoseLipCols):
        	y[:,index] = A[:,pos].copy()
	for pos,index in enumerate(RemainderCols):
        	y[:,index] = B[:,pos].copy()	
	return y
