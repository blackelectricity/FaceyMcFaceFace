import sys
sys.path.insert(0,'../UTIL')
import ImgUtil as IU
import NormUtil as NU
from TFlowModel import Model
import RunHelper as RH 

#DEFINE MODEL
print 'running part A'
model = Model({
	"X"  : '../DATA/F_Clean_Valid_X_VERY_SHRINK.npy',
	"Xwidth" : 24,
	"Xheight" : 24,
	"Ylength" : 8,
	"SaveDirectory": '../MODEL/A_SIMPLE/',
	"dimensionAfterConv": 24*24,
	"convLayers" : [],
	"fullLayers" : [[24*24, 24],[24, 8]]
})
Y_A = model.LoadAndRunModel()

print 'running part B'
model = Model({
	"X"  : '../DATA/F_Clean_Valid_X_VERY_SHRINK.npy',
	"Xwidth" : 24,
	"Xheight" : 24,
	"Ylength" : 22,
	"SaveDirectory": '../MODEL/B_SIMPLE/',
	"dimensionAfterConv": 24*24,
	"convLayers" : [],
	"fullLayers" : [[24*24, 24],[24, 22]]
})
Y_B = model.LoadAndRunModel()
	
print 'merging features'
Y = RH.MergeFeatures(Y_A, Y_B)

print 'preview result'
for inx in range(min(Y.shape[0], 3)):
	IU.ShowImageWithFeatureArray(model.X[inx], 24,24, Y[inx])
	IU.ShowImageWithFeatureArray(model.X[inx], 24,24, Y_A[inx])

print 'done'
	
