import numpy as np
import TFlowUtil as tu
import tensorflow as tf
from BatchUtil import Batch

class Model:

	def __init__(self, settingsDictionary):
		
		self.ConvKeepProbability = settingsDictionary.get("keepProbability")
		self.RegularizationFactor = settingsDictionary.get("regularizationFactor")
		self.DimensionAfterConv = settingsDictionary.get("dimensionAfterConv")
		self.Epocs = settingsDictionary.get("epocs")
		self.Prints = settingsDictionary.get("prints")
		self.Patience = settingsDictionary.get("patience")
		self.LearnLambda = settingsDictionary.get("learnLambda")
		self.BatchSize = settingsDictionary.get("batchSize")
		self.ConvLayers = settingsDictionary.get("convLayers")
		self.FullLayers = settingsDictionary.get("fullLayers")
		self.StopPooling = settingsDictionary.get("StopPooling")
		if (self.StopPooling == None):
			self.StopPooling = False 
		self.XWidth = settingsDictionary.get("Xwidth")
		self.XHeight = settingsDictionary.get("Xheight")
		self.YLength = settingsDictionary.get("Ylength")
		self.Logit = settingsDictionary.get("Logit")
		if (self.Logit == None):
			self.Logit = False
		self.XPath = settingsDictionary.get("X")
		self.YPath = settingsDictionary.get("Y")
		self.XCPath = settingsDictionary.get("XC")
		self.YCPath = settingsDictionary.get("YC")
		self.SavePath = settingsDictionary.get("SaveDirectory")
	
		self.TrainCost = []
		self.ValidCost = []
		self.RegCost = []
		
		self.weight = []
		self.bias = []
		self.EarlyStopCost = 99999999.999
		self.EarlyStopCount = 0	
		self.TotalLayers = 0
		self.ConvLogitMatrix = []
		self.FullLogitMatrix = []

		self.X = self.Y = self.XC = self.YC = np.array([])
	
	def SetupGraph(self, X, width, height, ConvLayers, FullLayers, Y, IsTraining):
		tu.ReshapeInputTo2DForConv(X, width, height, self)
		tu.AddConvolutionLayers(ConvLayers, self)
		tu.AddFullyConnectedLayers(FullLayers, self)
		tu.DropConvolveLoop(self, IsTraining)
		tu.ReshapeConvToFlatLayer(self)
		tu.FullyConnectedLoop(self)
		Y_ = tu.GetYHat(self)

		RegCost = tu.GetRegularizationCost(self)
		MSQE = tu.GetMeanSquaredError(Y, Y_)
		TotalCost = RegCost + MSQE
		Step = tf.train.AdamOptimizer(self.LearnLambda).minimize(TotalCost)

		return (Y_, RegCost, MSQE, TotalCost, Step)

	def TrainModel(self):
		print 'Loading Data'
		self.X = np.load(self.XPath)
		self.Y = np.load(self.YPath)
		self.XC = np.load(self.XCPath)
		self.YC = np.load(self.YCPath)	
		batch = Batch(self.X,self.Y,self.BatchSize)

		print 'Setting up Graph'
		with tf.device('/gpu:0'):
			x = tf.placeholder(tf.float32, shape=[None, self.XWidth*self.XHeight ])
			y = tf.placeholder(tf.float32, shape=[None, self.YLength ])
			train = tf.placeholder(tf.bool)
			
			(y_, reg, msqe, loss, step) = \
				self.SetupGraph(x, self.XWidth, self.XHeight, self.ConvLayers, self.FullLayers, y, train )

			init = tf.initialize_all_variables()

		print 'Initializing Variables'
		sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True))
		sess.run(init)

		print 'Running Training Loop'
		tu.Train(sess,reg,msqe,step,x,y,train,self,batch)		

		print 'Closing'
		sess.close()
		print 'Finished'

		
	def Save(self,sess):	
		np.save(self.SavePath + 'TCost.npy', self.TrainCost)
		np.save(self.SavePath + 'CCost.npy', self.ValidCost)
		for i in range(self.TotalLayers):
			np.save(self.SavePath + 'w' + str(i) + '.npy', sess.run(self.weight[i]))
			np.save(self.SavePath + 'b' + str(i) + '.npy', sess.run(self.bias[i]))

	def LoadAndRunModel(self):
		print 'Loading Data'	
		self.X = np.load(self.XPath).astype(np.float32)
		
		print 'Setting up Graph'
		with tf.device('/gpu:0'):
			tu.ReshapeInputTo2DForConv(tf.constant(self.X), self.XWidth, self.XHeight, self)
			tu.LoadConvolutionLayers(self.ConvLayers, self)
			tu.LoadFullyConnectedLayers(self.FullLayers, self)
			tu.DropConvolveLoop(self, tf.constant(False))
			tu.ReshapeConvToFlatLayer(self)
			tu.FullyConnectedLoop(self)
			Y_ = tu.GetYHat(self)

		print 'Initializing Variables'
		sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True))

		print 'Running Graph Evaluation Loop'
		YHAT = sess.run(Y_)

		print 'Closing'
		sess.close()
		print 'Finished'

		return YHAT
		





