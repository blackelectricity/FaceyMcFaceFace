import tensorflow as tf
import numpy as np
import TFlowModel as mod

seedy = 654321

def MakeVariable(shape):
	global seedy
	seedy += 1
	return tf.Variable(tf.truncated_normal(shape, mean=-0.000001, stddev=0.01, seed=seedy))

#expirement with activations 
def Lojit(z):
	z = tf.mul(0.2,tf.maximum(tf.mul(0.5,z), tf.mul(5.0,tf.log(tf.add(1.0,tf.maximum(-1.0,z))))))
	#z = tf.add(-5.0, tf.mul(1.2, tf.maximum(tf.mul(3.0,tf.log(tf.abs(tf.mul(50.0,z)))), tf.mul(2.0, tf.abs(z))  )))
	#z = tf.mul(z, tf.add(tf.add(0.1, tf.abs(tf.sin(z))), tf.abs(tf.sin(tf.add(z,1.557)))))
	return z

def Convolve(logit, shape, index, Model):
	x = tf.nn.conv2d(logit, Model.weight[index], strides=shape, padding='SAME')
	x = tf.add(x, Model.bias[index])
	if (Model.Logit):
		x = Lojit(x)
	else:
		x = tf.nn.tanh(x)
	return x

def MaxPool(logit, shape):
	return tf.nn.max_pool(logit, ksize=shape, strides=shape, padding='SAME')

def ReshapeInputTo2DForConv(X, width, height, Model):
	xi = tf.reshape(X, [-1, width, height, 1])
	Model.ConvLogitMatrix.append(xi)

def LoadConvolutionLayers(LayerSizes, Model):
	layerCount = 0
	for size in LayerSizes:
		Model.weight.append(tf.constant(np.load(Model.SavePath + 'w' + str(Model.TotalLayers + layerCount) + '.npy')))
		Model.bias.append(tf.constant(np.load(Model.SavePath + 'b' + str(Model.TotalLayers + layerCount) + '.npy')))
		layerCount += 1
	Model.ConvCountLayers = layerCount
	Model.ConvStartIndex = Model.TotalLayers 
	Model.TotalLayers += layerCount

def LoadFullyConnectedLayers(LayerSizes, Model):
	layerCount = 0
	for size in LayerSizes:
		Model.weight.append(tf.constant(np.load(Model.SavePath + 'w' + str(Model.TotalLayers + layerCount) + '.npy')))
		Model.bias.append(tf.constant(np.load(Model.SavePath + 'b' + str(Model.TotalLayers + layerCount) + '.npy')))
		layerCount += 1
	Model.FullCountLayers = layerCount
	Model.FullStartIndex = Model.TotalLayers 
	Model.TotalLayers += layerCount

def AddConvolutionLayers(LayerSizes, Model):
	layerCount = 0
	for size in LayerSizes:
		Model.weight.append(MakeVariable(size))
		Model.bias.append(MakeVariable([size[-1]]))
		layerCount += 1
	Model.ConvCountLayers = layerCount
	Model.ConvStartIndex = Model.TotalLayers 
	Model.TotalLayers += layerCount

def AddFullyConnectedLayers(LayerSizes, Model):
	layerCount = 0
	for size in LayerSizes:
		Model.weight.append(MakeVariable(size))
		Model.bias.append(MakeVariable([size[-1]]))
		layerCount += 1
	Model.FullCountLayers = layerCount
	Model.FullStartIndex = Model.TotalLayers 
	Model.TotalLayers += layerCount
 

def DropConvolveLoop(Model, DoDropout):
	for i in range(Model.ConvCountLayers):
		logit = Model.ConvLogitMatrix[i]
		conv = Convolve(logit, [1,1,1,1], Model.ConvStartIndex+i, Model)
		if (not(Model.ConvKeepProbability == None) and Model.ConvKeepProbability < 1.0):
			conv = tf.cond(DoDropout, lambda: tf.nn.dropout(conv, Model.ConvKeepProbability), lambda: conv)
		
		if (Model.StopPooling):
			pool = conv	
			Model.ConvLogitMatrix.append(pool)
		else: 
			pool = MaxPool(conv, [1,2,2,1])
			Model.ConvLogitMatrix.append(pool)

def FullyConnectedLoop(Model):
	for i in range(Model.FullCountLayers):
		logit = Model.FullLogitMatrix[i]
		weightedSum = tf.matmul( logit, Model.weight[Model.FullStartIndex + i] )
		x = weightedSum + Model.bias[Model.FullStartIndex + i]
		if (Model.Logit):
			x = Lojit(x)
		else:
			x = tf.nn.tanh(x)
		Model.FullLogitMatrix.append(x)

def ReshapeConvToFlatLayer(Model):
	cm = Model.ConvLogitMatrix[Model.ConvCountLayers]
	Model.FullLogitMatrix.append(tf.reshape(cm, [-1, Model.DimensionAfterConv]))
	

def GetRegularizationCost(Model):
	cost = 0.0
	for i in range(Model.TotalLayers):
		cost = cost + tf.reduce_mean(tf.square(Model.weight[i]))
		cost = cost + tf.reduce_mean(tf.square(Model.bias[i]))
	cost = ( cost / ( float(Model.TotalLayers) * 2.0 ) )
	cost = cost * Model.RegularizationFactor
	return cost

def GetYHat(Model):
	return Model.FullLogitMatrix[Model.FullCountLayers]

def GetMeanSquaredError(Y, Y_):
	MSQE = tf.reduce_mean(tf.square(tf.sub(Y,Y_)))
	return MSQE

def CheckEarlyStop(model, crossvalCost):
	save = False
	model.EarlyStopCount += 1
	if (model.EarlyStopCost > crossvalCost):
		model.EarlyStopCost = crossvalCost
		model.EarlyStopCount = 0
		save = True
	stop = model.EarlyStopCount > model.Patience
	return (save, stop)

def ValidatePrintSaveStop(sess, i, model, train_cost, train_reg_cost, valid_cost, valid_reg_cost):
	crossvalCost = valid_cost 
	trainingCost = train_cost
	model.TrainCost.append(trainingCost)
	model.ValidCost.append(crossvalCost)
	(save, stop) = CheckEarlyStop(model, crossvalCost)
	if (save):
		model.Save(sess)	
	print('i:' + str(i) + '\tCV:'+"{:7.9f}".format(crossvalCost) + '\tT:'+"{:7.9f}".format(trainingCost) + '\tSaved:' + str(save)) 	
	return stop

def Train(sess, reg, msqe, step, x, y, train, Model, batch):
	for i in range(Model.Epocs):
		(batchX, batchY) = batch.Next()
		if (i%Model.Prints == 0):
			(t_cost, t_reg_cost, _) = sess.run([msqe, reg, step], feed_dict={ x: batchX, y: batchY, train: True })
			(v_cost, v_reg_cost) = sess.run([msqe, reg], feed_dict={ x: Model.XC, y: Model.YC, train: False })
			earlyStop = ValidatePrintSaveStop(sess, i, Model, t_cost, t_reg_cost, v_cost, v_reg_cost)
			if (earlyStop):
				return
		else:
			sess.run([step], feed_dict={ x: batchX, y: batchY, train: True })
	return

