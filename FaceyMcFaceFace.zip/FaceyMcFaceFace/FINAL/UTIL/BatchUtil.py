import numpy as np

class Batch:

	def __init__(self, x, y, size):
		self.Size = size
		self.Index = -size
		self.Total = x.shape[0]
		self.X = x
		self.Y = y

	def Next(self):
		self.Index += self.Size
		self.Index = self.Index % self.Total
		if (self.Index + self.Size > self.Total):
			partAx = self.X[self.Index:].copy()
			partAy = self.Y[self.Index:].copy()
			partBx = self.X[0:((self.Index + self.Size) - self.Total)].copy()
			partBy = self.Y[0:((self.Index + self.Size) - self.Total)].copy()
			Tx = np.vstack((partAx, partBx))
			Ty = np.vstack((partAy, partBy))
			return (Tx,Ty)
		else:
			return ( \
				self.X[self.Index:(self.Index + self.Size)], \
				self.Y[self.Index:(self.Index + self.Size)] )

