import numpy as np

#Helper functions to quickly normalize data

EPSILON = 0.00000001

def DivMax(nparray):
	maxValue = np.max(nparray)
	maxValue = EPSILON if (maxValue <= EPSILON) else maxValue
	return nparray / maxValue

def SubMin(nparray):
	minValue = np.min(nparray)
	return nparray - minValue

def SubMean(nparray):
	avgValue = np.mean(nparray)
	return nparray - avgValue

#Scale Back to Int Range	
def ScaleInt(nparray, scale=255):
	nparray = SubMin(nparray)
	nparray = DivMax(nparray)
	nparray = (nparray * scale).astype(np.uint8)
	nparray = np.clip(nparray, 0, scale)
	return nparray

#Scale Back to Int range with Hard Set Transformation
def ScaleIntHard(nparray, offset = 0.5, scale = 96):
	nparray = nparray + offset
	nparray = nparray * scale
	nparray = np.clip(nparray.astype(np.uint8), 0, scale)
	return nparray

#Normalize Using Hard Set Transformation
def NormalizeHard(nparray, offset = 0.5, scale = 96.0):
	nparray = nparray / scale
	nparray = nparray - offset
	return nparray
	
#First Normalizes to [0,1] then subtracts mean
#Returns with mean 0 and values from [-1,1]
def NormalizeMean(nparray):
	nparray = SubMin(nparray)
	nparray = DivMax(nparray)
	nparray = SubMean(nparray)
	return nparray

#Find all rows with dead target features	
def FindDeadRows(nparray):
	deadRows = []
	for (index,yr) in enumerate(nparray.astype(np.float)):
		countDead = np.sum((np.isnan(yr)).astype(np.int))
		if (countDead > 0):
			deadRows.append(index)
	return deadRows

#Returns new (X,Y) arrays with Y's NaN target feature value rows removed from both
def RemoveDeadRows(X,Y):
	deadRows = FindDeadRows(Y)
	return ( np.delete(X,deadRows,0), np.delete(Y,deadRows,0) )



		
