import numpy as np
import NormUtil as NormU
from PIL import Image 

# Helper Class to View Images from Data arrays
# ALL FUNCTIONS ASSUME INPUT ARRAYS ARE FLAT AND ARE UNSCALED/NORMALIZED
# COMING IN WITH VALUES [-1,1], using NormUtil to scale them back below 
# THAT features come in reshapable as (feature.shape[0] / 2, 2) for (x,y) values
TARGET_SCALE = 96.0

def ScaleReshapeFeatures(features):
	scaledFeatures = NormU.ScaleIntHard(features)
	featureHalfShape = (features.shape[0] / 2)
	scaledFeatures = scaledFeatures.reshape((featureHalfShape, 2))
	return scaledFeatures
	
def GetFeaturePositions(features, width, height):
	scaleX = (width / TARGET_SCALE)
	scaleY = (height / TARGET_SCALE)
	positions = []
	for (ix, lbl) in enumerate(features):
		posX = int(lbl[1] * scaleX)
		posY = int(lbl[0] * scaleY)
		positions.append( [posX,posY] )
	return positions

def MarkPositions(nparray, positions, color):
	for pos in positions:
		nparray[pos[0], pos[1], :] = np.array(color).reshape((1,3))
	return nparray

def MarkFeatures(nparray, features, width, height, color):
	features = ScaleReshapeFeatures(features)
	positions = GetFeaturePositions(features, width, height)
	return MarkPositions(nparray, positions, color)

def ScaleReshapeArray(nparray, width, height):
	return NormU.ScaleInt(nparray).reshape((width, height))	

def ImageFromArray(nparray):
	return Image.fromarray(nparray, 'L')

def ShowColor(nparray):
	img = Image.fromarray(nparray, 'RGB')
	img = img.resize((200,200), Image.ANTIALIAS)
	img.show()

def Show(nparray):
	img = ImageFromArray(nparray)
	img = img.resize((200,200), Image.ANTIALIAS)
	img.show()

def ShowJPG(filename):
	img = Image.open(filename).convert('L')
	img = img.resize((200,200), Image.ANTIALIAS)
	img.show()

def GetArrayFromJPG(filename, width = 96, height = 96):
	img = Image.open(filename).convert('L')
	img = img.resize((width, height), Image.ANTIALIAS)
	return np.array(list(img.getdata())).astype(np.float).reshape((1,width*height))

def ColorizeArray(nparray):
	return np.dstack((nparray.copy(), nparray.copy(), nparray.copy()))

def ShrinkData(nparray, width, height, newWidth, newHeight):
	iArray = ScaleReshapeArray(nparray, width, height)
	img = ImageFromArray(iArray)
	img = img.resize((newWidth, newHeight), Image.ANTIALIAS)
	newArray = np.array(list(img.getdata())).astype(np.float).reshape((1, newWidth*newHeight))
	newArray = NormU.NormalizeMean(newArray)
	return newArray

def ShowImage(nparray, width, height):
	nparray = ScaleReshapeArray(nparray, width, height)
	Show(nparray)

def ShowImageWithFeatureArray(nparray, width, height, features):
	nparray = ScaleReshapeArray(nparray, width, height)
	nparray = ColorizeArray(nparray)
	nparray = MarkFeatures(nparray, features, width, height, [0,255,0])	
	ShowColor(nparray)

def ShowImageWithFeatureArrays(nparray, width, height, featuresA, featuresB):
	nparray = ScaleReshapeArray(nparray, width, height)
	nparray = ColorizeArray(nparray)
	nparray = MarkFeatures(nparray, featuresA, width, height, [0, 255, 0])
	nparray = MarkFeatures(nparray,	featuresB, width, height, [0, 0, 255])
	ShowColor(nparray)



