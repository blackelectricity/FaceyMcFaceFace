import sys
sys.path.insert(0,'../UTIL')
from TFlowModel import Model

#DEFINE MODEL
model = Model({
	"X"  : '../DATA/B_Clean_Train_X_VERY_SHRINK.npy',
	"Y"  : '../DATA/B_Clean_Train_Y.npy',
	"XC" : '../DATA/B_Clean_Cross_X_VERY_SHRINK.npy',
	"YC" : '../DATA/B_Clean_Cross_Y.npy',
	"Xwidth" : 24,
	"Xheight" : 24,
	"Ylength" : 22,
	"SaveDirectory": '../MODEL/B_SIMPLE/',
	"regularizationFactor": 2.0,
	"dimensionAfterConv": 24*24,
	"epocs": 8000,
	"prints": 10,
	"patience": 50,
	"learnLambda": 0.001,
	"batchSize": 5000,
	"convLayers" : [],
	"fullLayers" : [[24*24, 128],[128, 22]]
})
print model.Epocs
model.TrainModel()
print 'Training Finished'
	
	


