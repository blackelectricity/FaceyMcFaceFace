import sys
sys.path.insert(0,'../UTIL')
from TFlowModel import Model

#DEFINE MODEL
model = Model({
	"X"  : '../DATA/A_Clean_Train_X_SHRINK.npy',
	"Y"  : '../DATA/A_Clean_Train_Y.npy',
	"XC" : '../DATA/A_Clean_Cross_X_SHRINK.npy',
	"YC" : '../DATA/A_Clean_Cross_Y.npy',
	"Xwidth" : 48,
	"Xheight" : 48,
	"Ylength" : 8,
	"SaveDirectory": '../MODEL/A/',
	"keepProbability": 0.75,
	"regularizationFactor": 5.0,
	"dimensionAfterConv": 57600,
	"epocs": 8000,
	"prints": 10,
	"patience": 50,
	"learnLambda": 0.001,
	"batchSize": 500,
	"convLayers" : [[18,18,1,100]],
	"fullLayers" : [[57600, 64],[64, 8]]
})
print model.Epocs
model.TrainModel()
print 'Training Finished'
	
	


