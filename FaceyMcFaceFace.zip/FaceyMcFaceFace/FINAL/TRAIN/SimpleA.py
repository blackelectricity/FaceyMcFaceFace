import sys
sys.path.insert(0,'../UTIL')
from TFlowModel import Model

#DEFINE MODEL
model = Model({
	"X"  : '../DATA/A_Clean_Train_X_VERY_SHRINK.npy',
	"Y"  : '../DATA/A_Clean_Train_Y.npy',
	"XC" : '../DATA/A_Clean_Cross_X_VERY_SHRINK.npy',
	"YC" : '../DATA/A_Clean_Cross_Y.npy',
	"Xwidth" : 24,
	"Xheight" : 24,
	"Ylength" : 8,
	"SaveDirectory": '../MODEL/A_SIMPLE/',
	"regularizationFactor": 0.5,
	"dimensionAfterConv": 24*24,
	"epocs": 8000,
	"prints": 10,
	"patience": 50,
	"learnLambda": 0.001,
	"batchSize": 5000,
	"convLayers" : [],
	"fullLayers" : [[24*24, 64],[64, 8]]
})
print model.Epocs
model.TrainModel()
print 'Training Finished'
	
	


