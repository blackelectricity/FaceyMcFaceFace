import sys 
sys.path.insert(0, '../UTIL')
import ImgUtil 

import numpy as np
from PIL import Image
from math import sqrt


#SHOW FIRST IMAGE IN EACH DATA SET, WITH FEATURE LABELS IF AVAILABLE

def prev(fileNAME, hasY):
        #load data
	x = np.load('../DATA/' + fileNAME + '_X.npy')
        xshrink = np.load('../DATA/' + fileNAME + '_X_VERY_SHRINK.npy')
	
	#images are square, no need to check height
        width = int(sqrt(x.shape[1])) 
        widthShrink = int(sqrt(xshrink.shape[1]))
        print width, widthShrink 
      
	#show data for preview 
	if (not(hasY)):
                ImgUtil.ShowImage(x[0],width,width)
                ImgUtil.ShowImage(xshrink[0],widthShrink,widthShrink)
        else:
		#load feature data too and show it
                y = np.load('../DATA/' + fileNAME + '_Y.npy')
                ImgUtil.ShowImageWithFeatureArray(x[0],width,width,y[0])
                ImgUtil.ShowImageWithFeatureArray(xshrink[0], widthShrink,widthShrink, y[0])

def Preview(fileArrays,hasY):
        for filename in fileArrays:
                print 'start: ' + filename
                prev(filename,hasY)
                print filename + ' is done'
                print '------'
                raw_input()

print 'STARTING'
         
#Datasets with features   
Preview([ \
        'A_Clean_Full', \
        'B_Clean_Full', \
        'A_Clean_Train', \
        'B_Clean_Train', \
        'A_Clean_Cross', \
        'B_Clean_Cross', \
        ],True)

#Datasets Without Features
Preview([ \
        'F_Clean_Test', \
        'F_Clean_Valid', \
        ],False)
            

print 'DONE'
