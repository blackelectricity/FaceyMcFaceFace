import sys
sys.path.insert(0, '../UTIL')

import ImgUtil
import numpy as np
from PIL import Image

CVTEST = np.zeros((8,96*96))
for i in range(8):
	fname = '../DATA/TestPics/' + str(i) + '.JPG'
	CVTEST[i] = ImgUtil.GetArrayFromJPG(fname)
	ImgUtil.ShowJPG(fname)

np.save('../DATA/validX.npy',CVTEST)




