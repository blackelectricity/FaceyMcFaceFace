import numpy as np
import pandas as pd

print 'START'
train_file = '../DATA/training.csv'
test_file = '../DATA/test.csv'

print 'READING TRAINING'
df_train = pd.read_csv(train_file)

print 'READING TEST'
df_test = pd.read_csv(test_file)

print 'FORMATTING TRAINING'
df_train['Image'] = df_train['Image'].apply(lambda spacey: np.fromstring(spacey, sep=' '))

print 'FORMATTING TESTING'
df_test['Image'] = df_test['Image'].apply(lambda spacey: np.fromstring(spacey, sep=' '))

print 'SPLICING TRAIN XY'
XY_train = df_train.values
print XY_train.shape
np.save('../DATA/XY_train.npy', XY_train)

print 'SPLICING TEST X'
X_test = df_test.ix[:,-1:].values
print X_test.shape
np.save('../DATA/X_test.npy', X_test)

print 'DONE'

