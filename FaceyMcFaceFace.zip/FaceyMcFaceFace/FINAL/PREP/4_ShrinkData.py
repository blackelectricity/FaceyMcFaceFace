import sys
sys.path.insert(0, '../UTIL')
import ImgUtil
import numpy as np

def AShrink(xarrays, w, h, suffix):
        for arName in xarrays:
                print 'start: ' + arName
		x = np.load('../DATA/' + arName + '_X.npy')
        	
		x2 = np.zeros((x.shape[0], w * h))
        	for (i,xr) in enumerate(x):
        		x2[i,:] = ImgUtil.ShrinkData(xr, 96, 96, w, h)	
		np.save('../DATA/' + arName + '_X_' + suffix + '.npy', x2) 
		print arName + ' is done'
                print '------------------------'

print 'STARTING'
    
AShrink([ \
        'A_Clean_Full', \
        'B_Clean_Full', \
        'A_Clean_Train', \
        'B_Clean_Train', \
        'A_Clean_Cross', \
        'B_Clean_Cross', \
        'F_Clean_Test', \
        'F_Clean_Valid', \
        ], 48,48,'SHRINK')  
print 'starting second batch' 
AShrink([ \
        'A_Clean_Full', \
        'B_Clean_Full', \
        'A_Clean_Train', \
        'B_Clean_Train', \
        'A_Clean_Cross', \
        'B_Clean_Cross', \
        'F_Clean_Test', \
        'F_Clean_Valid', \
        ], 24,24,'VERY_SHRINK')  

print 'DONE'
