import sys
sys.path.insert(0,'../UTIL')

import NormUtil
import numpy as np

def CleanArrays(XIN,YIN,XOUT,YOUT):
        print XIN,YIN
	#LOAD
        xin = np.load('../DATA/' + XIN + '.npy')
        yin = np.load('../DATA/' + YIN + '.npy')
        print xin.shape, yin.shape
	#REMOVE EMPTY FEATURE ROWS
        (xin, yin) = NormUtil.RemoveDeadRows(xin,yin)
        print xin.shape, yin.shape
	#NORMALIZE
        xin = NormUtil.NormalizeMean(xin) 
        yin = NormUtil.NormalizeHard(yin)
        print xin.shape, yin.shape
	#SAVE
        np.save('../DATA/' + XOUT + '.npy', xin)
        np.save('../DATA/' + YOUT + '.npy', yin)
        print XOUT, YOUT
        print '--------------------------------------'


print 'START FULL CLEAN'
CleanArrays('fullX','fullYa','A_Clean_Full_X','A_Clean_Full_Y')
CleanArrays('fullX','fullYb','B_Clean_Full_X','B_Clean_Full_Y')

print 'START TRAIN CLEAN'
CleanArrays('trainX','trainYa','A_Clean_Train_X','A_Clean_Train_Y')
CleanArrays('trainX','trainYb','B_Clean_Train_X','B_Clean_Train_Y')

print 'START CROSS CLEAN'
CleanArrays('crossX','crossYa','A_Clean_Cross_X','A_Clean_Cross_Y')
CleanArrays('crossX','crossYb','B_Clean_Cross_X','B_Clean_Cross_Y')

print 'CLEAN TEST X'
testX = np.load('../DATA/testX.npy')
testX = NormUtil.NormalizeMean(testX)
np.save('../DATA/F_Clean_Test_X.npy',testX)

print 'CLEAN VALID X'
validX = np.load('../DATA/validX.npy')
validX = NormUtil.NormalizeMean(validX)
np.save('../DATA/F_Clean_Valid_X.npy',validX)

print 'DONE'
