HOW TO RUN FROM START TO SUBMISSION.csv:
(uses python 2.7, tensorflow, PIL, sklearn, numpy and an Xwindow shell connection to the machine,if cuda not installed or no gpu, unindent and remove the line in UTIL/TFlowModel TrainModel function's: with tf.device('/gpu:0')  
1. Put the train.csv, test.csv, and IdLookupTable.csv directly in the DATA directory
2. Go to the PREP directory and run all .py files in numbered order.
3. Go to the TRAIN directory and run all the .py files, watch output as networks train.
4. Go to the RUN directory, 
	a. use ViewChart.py and ViewSimpleChart.py to see learning curves 
	b. run RunTestModels.py and RunTestSimple.py to run the trained models and save and preview results. 
	c. run MakeTestSubmission.py and MakeSimpleTestSubmission.py to create the submission.csv files.
	d. the submission.csv files will be located in the DATA directory
 
