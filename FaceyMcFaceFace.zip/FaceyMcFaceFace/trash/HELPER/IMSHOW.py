import numpy as np
from PIL import Image
from math import floor
from math import sqrt
def Show(grayscale_image_flat, w, h):
	im1 = grayscale_image_flat.copy()
	mini = np.min(im1)
	im1 = im1 - mini
	maxi = np.max(im1)
	im1 = im1 / (maxi + 0.000000000001)
	im1 = im1 * 255.0
	im1 = (im1).astype(np.int)
	im1 = np.clip(im1,0,255)
	im1 = im1.reshape((w,h))
	im1 = np.dstack((im1.copy(), im1.copy(), im1.copy()))
	img = Image.fromarray(im1.astype(np.uint8).copy(),'RGB')
	img = img.resize((200,200), Image.ANTIALIAS)
	img.show()

def ShowWithFeature(grayscale_image_flat, label_flat, w,h):
	lb1 = ((label_flat.copy() + 0.5) * 96.0).astype(np.int)
	lb1 = np.clip(lb1,0,96) 
	lb1 = lb1.reshape((lb1.shape[0]/2,2))
	
	im1 = grayscale_image_flat.copy()
	mini = np.min(im1)
	im1 = im1 - mini
	maxi = np.max(im1)
	im1 = im1 / (maxi + 0.000000000001)
	im1 = im1 * 255.0
	im1 = (im1).astype(np.int)
	im1 = np.clip(im1,0,255)
	im1 = im1.reshape((w,h))
	im1 = np.dstack((im1.copy(), im1.copy(), im1.copy()))
	
	sx = (w / 96.0)
	sy = (h / 96.0)

	for ix in range(lb1.shape[0]):
		mx = int(floor(lb1[ix,1]*sx))
		my = int(floor(lb1[ix,0]*sy))
		im1[mx,my] = [0,255,0]

	img = Image.fromarray(im1.astype(np.uint8).copy(),'RGB')
	img = img.resize((200,200), Image.ANTIALIAS)
	img.show()

def ShowWithDoubleFeature(grayscale_image_flat, label_flat, label_flat2, w, h):
	lb1 = ((label_flat.copy() + 0.5) * 96.0).astype(np.int)
	lb1 = np.clip(lb1,0,96) 
	lb1 = lb1.reshape((lb1.shape[0]/2,2))
	
	lb2 = ((label_flat2.copy() + 0.5) * 96.0).astype(np.int)
	lb2 = np.clip(lb2,0,96) 
	lb2 = lb2.reshape((lb2.shape[0]/2,2))
	
	im1 = grayscale_image_flat.copy()
	mini = np.min(im1)
	im1 = im1 - mini
	maxi = np.max(im1)
	im1 = im1 / (maxi + 0.000000000001)
	im1 = im1 * 255.0
	im1 = (im1).astype(np.int)
	im1 = np.clip(im1,0,255)
	im1 = im1.reshape((w,h))
	im1 = np.dstack((im1.copy(), im1.copy(), im1.copy()))

	sx = (w / 96.0)
	sy = (h / 96.0)

	for ix in range(lb1.shape[0]):
		mx = int(floor(lb1[ix,1]*sx))
		my = int(floor(lb1[ix,0]*sy))
		im1[mx,my] = [0,255,0]
	for ix in range(lb2.shape[0]):
		mx = int(floor(lb2[ix,1]*sx))
		my = int(floor(lb2[ix,0]*sy))
		im1[mx,my] = [0,0,255]
	img = Image.fromarray(im1.astype(np.uint8).copy(),'RGB')
	img = img.resize((200,200), Image.ANTIALIAS)
	img.show()

