import numpy as np
from PIL import Image

w = np.load('w0.npy')
print w.shape
fw = w.shape[0]
fh = w.shape[1]
fd = w.shape[2]
fc = 10
fc2 = 10
bigFilt = np.zeros((fc*(fw+2), fc2*(fh+2), fd)).astype(np.uint8)
for x in range(fc):
	for y in range(fc2):
		filt = w[:,:,:,x*fc2 + y].copy().reshape((fw,fh,fd))
		minf = np.min(filt)
		filt = filt - minf + 0.00000000001
		maxf = np.max(filt)
		filt = filt / (maxf + 0.00000000001)
		filt = filt * 255.0
		filt = np.clip(filt, 0, 255).astype(np.uint8)
		bigSX = x*(fw+2) + 2
		bigEX = bigSX + fw 
		bigSY = y*(fh+2) + 2
		bigEY = bigSY + fh 
		bigFilt[bigSX:bigEX, bigSY:bigEY, :] = filt.copy() 

im = None
if (fd == 3):
	im = Image.fromarray(bigFilt, 'RGB')
else:
	im = Image.fromarray(bigFilt[:,:,0], 'L')	
im = im.resize((800,800),Image.ANTIALIAS)
im.show()

			
