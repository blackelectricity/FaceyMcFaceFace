import sys
sys.path.insert(0,'../../../HELPER')
import IMSHOW as ims
import tensorflow as tf
import numpy as np

X  = np.load('../../../DATA/F_Clean_Test_X_SHRINK.npy')

with tf.device('/gpu:0'):
	x = tf.placeholder(tf.float32, shape=[ None, 48*48 ])
	xi = tf.reshape(x, [-1, 48, 48, 1])	

	weight_matrixA = []
	bias_matrixA = []
	full_matrixA = []

	weight_matrixB = []
	bias_matrixB = []
	full_matrixB = []

        def loadModel(subdir,weight_matrix,bias_matrix,index):
                w = np.load('../MODEL/'+subdir+'/w' + str(index) + '.npy')    
                waity = tf.constant(w, shape=list(w.shape))          
                b = np.load('../MODEL/'+subdir+'/b' + str(index) + '.npy')    
                biasy = tf.constant(b, shape=list(b.shape))          
                weight_matrix.append(waity)                          
                bias_matrix.append(biasy)                            

	for i in range(3):
		loadModel('0',weight_matrixA,bias_matrixA,i)
	
	for i in range(3):
		loadModel('1',weight_matrixB,bias_matrixB,i)
	
	convsA = 1
	convsB = 1
	dimmyA = 24*24*100
	dimmyB = 24*24*110
	fullsA = len(weight_matrixA) - convsA
	fullsB = len(weight_matrixB) - convsB

	tcA = tf.nn.conv2d(xi,weight_matrixA[0],strides=[1,1,1,1],padding='SAME')
	bcA = tf.add(tcA, bias_matrixA[0])
	pcA = tf.nn.max_pool(bcA,ksize=[1,2,2,1],strides=[1,2,2,1],padding='SAME')
	full_matrixA.append(tf.reshape(tf.nn.tanh(pcA), [-1,dimmyA]))
	
	tcB = tf.nn.conv2d(xi,weight_matrixB[0],strides=[1,1,1,1],padding='SAME')
	bcB = tf.add(tcB, bias_matrixB[0])
	pcB = tf.nn.max_pool(bcB,ksize=[1,2,2,1],strides=[1,2,2,1],padding='SAME')
	full_matrixB.append(tf.reshape(tf.nn.tanh(pcB), [-1,dimmyB]))

	for i in range(0,fullsA-1):
		mm = tf.matmul( full_matrixA[i], weight_matrixA[i+convsA] )
		hv = tf.nn.tanh( mm + bias_matrixA[i+convsA])
		full_matrixA.append(hv)
	
	for i in range(0,fullsB-1):
		mm = tf.matmul( full_matrixB[i], weight_matrixB[i+convsB] )
		hv = tf.nn.tanh( mm + bias_matrixB[i+convsB])
		full_matrixB.append(hv)

	#output layer A
	i = fullsA-1
	mm = tf.matmul( full_matrixA[i], weight_matrixA[i+convsA] )
	y_a = tf.nn.tanh( mm + bias_matrixA[i+convsA] )
	
	i = fullsB-1	
	mm = tf.matmul( full_matrixB[i], weight_matrixB[i+convsB] )
	y_b = tf.nn.tanh( mm + bias_matrixB[i+convsB] )
			
	init = tf.initialize_all_variables()

sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True))
sess.run(init)

(y_a,y_b) = sess.run([y_a,y_b], feed_dict= {  x: X  } )

y = np.zeros((y_a.shape[0], 30))
EyesNoseLipCols = [0,1,2,3,20,21,28,29] 
RemainderCols = [4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,22,23,24,25,26,27]

for pos,index in enumerate(EyesNoseLipCols):
	y[:,index] = y_a[:,pos].copy()

for pos,index in enumerate(RemainderCols):
	y[:,index] = y_b[:,pos].copy()

#y[:,21] = (y[:,21] + .02).copy()

for inx in range(min(10,max(X.shape[0],3))):
	ims.ShowWithFeature(X[inx], y[inx], 48,48)

y = y + 0.5
y = y * 96.0
y = np.clip(y,0,96).astype(np.int)
np.save('../MODEL/YHAT.npy', y)

print 'afinit'
sess.close()
print 'finito'
	
