import tensorflow as tf
import numpy as np

epocs   = 300000
prins  	= 150 
saves   = 150
patience   = 10
batch_size = 200

tlambda = 0.000005
l2val   = 0.01


X  = np.load('../../../DATA/A_Clean_Train_X_HAT.npy')[:,0,:].copy()
Y  = np.load('../../../DATA/A_Clean_Train_Y.npy')[:,:2].copy()

XC = np.load('../../../DATA/A_Clean_Cross_X_HAT.npy')[:,0,:].copy()
YC = np.load('../../../DATA/A_Clean_Cross_Y.npy')[:,:2].copy()


TRAIN_COST = []
VALID_COST = []

with tf.device('/gpu:0'):
	x = tf.placeholder(tf.float32, shape=[ None, 24*24+2 ])
	y = tf.placeholder(tf.float32, shape=[ None, 2 ])
	
	seedy = 654321

	weight_matrix = []
	bias_matrix = []
	conv_matrix = []
	full_matrix = []

	def trunv(shape):
		global seedy
		seedy+=1
		return tf.Variable(tf.truncated_normal(shape,mean=-0.0001,stddev=0.01,seed=seedy))

	def vary(shape):
		global bias_matrix
		global weight_matrix
		waity = trunv(shape)	
		lenny = len(shape)
		bilen = shape[lenny-1]
		biasy = trunv([bilen])
		weight_matrix.append(waity)
		bias_matrix.append(biasy)


	vary([24*24+2,64])
	vary([64,64])
	vary([64,2])

	fulls = len(weight_matrix) 

	full_matrix.append(x)
	for i in range(fulls-1):
		mm = tf.matmul( full_matrix[i], weight_matrix[i] )
		hv = tf.nn.tanh( mm + bias_matrix[i])
		full_matrix.append(hv)

	#output layer	
	i = fulls-1		
	mm = tf.matmul( full_matrix[i], weight_matrix[i] )
	y_ = tf.nn.tanh( mm + bias_matrix[i] )
	cost = tf.reduce_mean(tf.square(tf.sub(y_,y)))

	regn = 0.0
	tots = len(weight_matrix)	
	for wix in range(tots):
		regn = regn + tf.reduce_mean(tf.square(weight_matrix[wix]))
		regn = regn + tf.reduce_mean(tf.square(bias_matrix[wix]))
	regn = regn / (tots * 2)
	regn = l2val * regn
	cost = cost + regn
		
	train_step = tf.train.AdamOptimizer(tlambda).minimize(cost)
			
	init = tf.initialize_all_variables()

sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True))
sess.run(init)

cur_pat    = 0
miniVAL    = 10000000.0

def printTest(i,c):
	global miniVAL
	global cur_pat
	returnVal = False
	if (i%prins == 0):
		(costo) = sess.run([cost], feed_dict={ y:YC , x:XC }) #NEVER RUN train_step on Validation set
		if (costo[0] < miniVAL):
			miniVAL = costo[0]
			cur_pat = 0
			returnVal = True #NEW MINIMUM VALIDATION SCORE REACHED, RETURN TRUE SO SAVE WILL SAVE WEIGHTS	
		else:
			cur_pat += 1
		TRAIN_COST.append(c)
		VALID_COST.append(costo[0])
		print('i:' + str(i) + '\tC:'+"{:7.9f}".format(costo[0]) + '\tT:'+"{:7.9f}".format(c))

	return returnVal

def saveTest(i,v):
	if (i%saves == 0):
		np.save('../MODEL/0/0/TCost.npy', TRAIN_COST)
		np.save('../MODEL/0/0/VCost.npy', VALID_COST)
		print 'saved scores'
		if (v):	
			for i in range(len(weight_matrix)):
				np.save('../MODEL/0/0/w'+str(i)+'.npy',sess.run(weight_matrix[i]))
			for i in range(len(bias_matrix)):
				np.save('../MODEL/0/0/b'+str(i)+'.npy',sess.run(bias_matrix[i]))
			print 'saved weights'

BatchSize = batch_size
BatchIndex = -BatchSize
TotalSize = X.shape[0]
def GetTrainBatch():
	global BatchIndex
	BatchIndex = BatchIndex + BatchSize 
	BatchIndex = BatchIndex % TotalSize
	if (BatchIndex + BatchSize > TotalSize):
		partAy= Y[BatchIndex:].copy()
		partAz= X[BatchIndex:].copy()
		partBy= Y[0:((BatchIndex + BatchSize) - TotalSize)].copy()
		partBz= X[0:((BatchIndex + BatchSize) - TotalSize)].copy()
		yt2 = np.vstack((partAy,partBy))
		zt2 = np.vstack((partAz,partBz))
		return (yt2,zt2)
	else:
		return ( \
			Y[BatchIndex:(BatchIndex + BatchSize)], \
			X[BatchIndex:(BatchIndex + BatchSize)])
		
for i in range(epocs+1):
	c = 0.0
	(yT,zT) = GetTrainBatch()
	if (i%prins == 0):
		(res,c,regr) = sess.run([train_step,cost,regn], feed_dict={  y: yT, x:zT })
		print regr
	else:
		(res) = sess.run([train_step], feed_dict={  y: yT, x:zT  })
	v = printTest(i,c)
	saveTest(i,v)
	if (cur_pat > patience):
		print 'early stopping'
		break

print 'afinit'
sess.close()

print 'finito'
	
