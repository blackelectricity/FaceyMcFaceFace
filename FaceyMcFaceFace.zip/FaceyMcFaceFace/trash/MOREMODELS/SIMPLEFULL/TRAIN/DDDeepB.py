import tensorflow as tf
import numpy as np

epocs   = 20000
prins  	= 10
saves   = 10
patience   = 200
batch_size = 500

tlambda = 0.0001
l2val   = 5
dop = 0.75 

X  = np.load('../../../DATA/B_Clean_Train_X_SHRINK.npy')
Y  = np.load('../../../DATA/B_Clean_Train_Y.npy')

XC = np.load('../../../DATA/B_Clean_Cross_X_SHRINK.npy')
YC = np.load('../../../DATA/B_Clean_Cross_Y.npy')


TRAIN_COST = []
VALID_COST = []
REGUL_COST = []
with tf.device('/gpu:0'):
	x = tf.placeholder(tf.float32, shape=[ None, 48*48 ])
	xi = tf.reshape(x, [-1, 48,48, 1])
	y = tf.placeholder(tf.float32, shape=[ None, 22 ])
	
	seedy = 654321

	weight_matrix = []
	bias_matrix = []
	conv_matrix = []
	full_matrix = []

	def trunv(shape):
		global seedy
		seedy+=1
		return tf.Variable(tf.truncated_normal(shape,mean=-0.000001,stddev=0.01,seed=seedy))

	def vary(shape):
		global bias_matrix
		global weight_matrix
		waity = trunv(shape)	
		lenny = len(shape)
		bilen = shape[lenny-1]
		biasy = trunv([bilen])
		weight_matrix.append(waity)
		bias_matrix.append(biasy)

        def tanconv(logit,shapeypoo,nummy):
                x = tf.nn.conv2d(logit,weight_matrix[nummy],strides=shapeypoo,padding='SAME')  
                x = tf.add(x, bias_matrix[nummy])
                return tf.nn.tanh(x)

        def poolio(logit, shapeypoo):
                  return tf.nn.max_pool(logit,ksize=shapeypoo,strides=shapeypoo,padding='SAME')

	
        #CONV LAYERS
	SH = [100]
	vary([18,18,1,SH[0]])
		
        convs = len(weight_matrix)

        #FULLY CONNECTED LAYERS
        dimmy = 24*24*np.sum(SH)
        vary([dimmy,64])
        vary([64,22])

        fulls = len(weight_matrix)  - convs
        conv_matrix.append(xi)

	#cm = conv_matrix[0]
	#tc = tanconv(cm, [1,1,1,1], 0)
	#pc = poolio(tc, [1,2,2,1])
	#conv_matrix.append(pc)
	#conv_matrix.append(tc)

        for i in range(convs):
                cm = conv_matrix[0]
                tc = tanconv(cm, [1,1,1,1], i)
		tc = tf.nn.dropout(tc,dop)
                pc = poolio(tc, [1,2,2,1])
		rc = tf.reshape(pc, [-1,24*24,SH[i]])
                conv_matrix.append(rc)  

	fcat = tf.concat(2,conv_matrix[1:])
	fcat = tf.reshape(fcat, [-1,24*24*np.sum(SH)])
	
        #full_matrix.append(tf.reshape(conv_matrix[convs], [-1,dimmy]))
	full_matrix.append(fcat)
        for i in range(fulls-1):
                mm = tf.matmul( full_matrix[i], weight_matrix[i+convs] )
		hv = mm + bias_matrix[i+convs]
		hv = tf.maximum(0.25 * hv, hv)
                #hv = tf.nn.tanh( mm + bias_matrix[i+convs])
                full_matrix.append(hv)

        #LAST LAYER NEVER DROPOUT 
        i = fulls-1
        mm = tf.matmul( full_matrix[i], weight_matrix[i+convs] )
        y_ = tf.nn.tanh( mm + bias_matrix[i+convs] )
        #my =  mm + bias_matrix[i+convs] 
        #y_ = tf.maximum( 0.25*my, my )
	cost = tf.reduce_mean(tf.square(tf.sub(y_,y)))

	regn = 0.0
	tots = len(weight_matrix)	
	for wix in range(tots):
		regn = regn + tf.reduce_mean(tf.square(weight_matrix[wix]))
		regn = regn + tf.reduce_mean(tf.square(bias_matrix[wix]))
	regn = regn / (tots * 2)
	regn = l2val * regn
	cost = cost + regn
		
	train_step = tf.train.AdamOptimizer(tlambda).minimize(cost)
			
	init = tf.initialize_all_variables()

sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True))
sess.run(init)

cur_pat    = 0
miniVAL    = 10000000.0

def printTest(i,c,regr):
	global miniVAL
	global cur_pat
	returnVal = False
	if (i%prins == 0):
		(costo) = sess.run([cost], feed_dict={ y:YC , x:XC }) #NEVER RUN train_step on Validation set
		if (costo[0] < miniVAL):
			miniVAL = costo[0]
			cur_pat = 0
			returnVal = True #NEW MINIMUM VALIDATION SCORE REACHED, RETURN TRUE 2 SAVE	
		else:
			cur_pat += 1
		TRAIN_COST.append(c)
		VALID_COST.append(costo[0])
		REGUL_COST.append(regr)
		fs = (max(costo[0],c) - regr)
		print('i:' + str(i)+ '\tR:'+"{:7.9f}".format(regr)  + '\tC:'+"{:7.9f}".format(costo[0]) + '\tT:'+"{:7.9f}".format(c)+ '\tF:'+"{:7.9f}".format(fs))

	return returnVal

def saveTest(i,v):
	if (i%saves == 0):
		np.save('../MODEL/1/TCost.npy', TRAIN_COST)
		np.save('../MODEL/1/VCost.npy', VALID_COST)
		np.save('../MODEL/1/RCost.npy', REGUL_COST)
		print 'saved scores'
		if (v):	
			for i in range(len(weight_matrix)):
				np.save('../MODEL/1/w'+str(i)+'.npy',sess.run(weight_matrix[i]))
			for i in range(len(bias_matrix)):
				np.save('../MODEL/1/b'+str(i)+'.npy',sess.run(bias_matrix[i]))
			print 'saved weights'

BatchSize = batch_size
BatchIndex = -BatchSize
TotalSize = X.shape[0]
def GetTrainBatch():
	global BatchIndex
	BatchIndex = BatchIndex + BatchSize 
	BatchIndex = BatchIndex % TotalSize
	if (BatchIndex + BatchSize > TotalSize):
		partAy= Y[BatchIndex:].copy()
		partAz= X[BatchIndex:].copy()
		partBy= Y[0:((BatchIndex + BatchSize) - TotalSize)].copy()
		partBz= X[0:((BatchIndex + BatchSize) - TotalSize)].copy()
		yt2 = np.vstack((partAy,partBy))
		zt2 = np.vstack((partAz,partBz))
		return (yt2,zt2)
	else:
		return ( \
			Y[BatchIndex:(BatchIndex + BatchSize)], \
			X[BatchIndex:(BatchIndex + BatchSize)])
		
for i in range(epocs+1):
	c = 0.0
	(yT,zT) = GetTrainBatch()
	if (i%prins == 0):
		(res,c,regr) = sess.run([train_step,cost,regn], feed_dict={  y: yT, x:zT })
		v = printTest(i,c,regr)
		saveTest(i,v)
		if (cur_pat > patience):
			print 'early stopping'
			break
	else:
		(res) = sess.run([train_step], feed_dict={  y: yT, x:zT  })

print 'afinit'
sess.close()

print 'finito'
	
