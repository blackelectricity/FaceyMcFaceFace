import numpy as np
from PIL import Image

x = np.load('../../../DATA/A_Clean_Cross_X.npy').reshape((-1,96,96))
y = np.load('../../../DATA/A_Clean_Cross_Y_HAT.npy')
feat = y.shape[1] / 2
lent = y.shape[0]
y = y.reshape((lent, feat, 2)) 
yn = (y / 255.0) - 0.5
ys = np.clip((y - 12),0,96)
yb = np.clip((y + 12),0,96)

z = np.zeros((lent, feat, 24*24+2))

for i in range(lent):
	for j in range(feat):
		w = yb[i][j][1] - ys[i][j][1]
		h = yb[i][j][0] - ys[i][j][0] 
		zx = x[i][ \
				ys[i][j][1] : yb[i][j][1], \
				ys[i][j][0] : yb[i][j][0]  \
		 	 ] 
		zx = np.clip(((zx + 0.5) * 255.0), 0, 255)	
		zx = zx.reshape((w,h)).astype(np.uint8)
		zi = Image.fromarray(zx ,'L')
		zi = zi.resize((24,24), Image.ANTIALIAS)
		zd = (np.array(list(zi.getdata())).astype(np.float) / 255.0) - 0.5 
		z[i][j] = np.append(zd, [ yn[i][j][0] , yn[i][j][1] ] )

np.save('../../../DATA/A_Clean_Cross_X_HAT.npy', z)		
