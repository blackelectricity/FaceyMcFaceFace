import numpy as np

yh = np.load('../MODEL/YHAT.npy')
idref = np.load('../../../DATA/IDREF.npy')

counter = 1
f = open('../MODEL/submission.csv','w')
f.write('RowId,Location\n')
for i in range(len(idref)):
        image = idref[i][0] - 1
        feat = idref[i][1]
        location = int(yh[image][feat])
        stringy = str(counter) + ',' + str(location) + '\n'
        f.write(stringy)
        counter = counter + 1
f.close()

