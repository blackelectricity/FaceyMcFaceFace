import sys
sys.path.insert(0,'../../../HELPER')
import IMSHOW as ims
import tensorflow as tf
import numpy as np

X  = np.load('../../../DATA/A_Clean_Train_X_SHRINK.npy')

with tf.device('/gpu:0'):
	
	x = tf.placeholder(tf.float32, shape=[ None, 48*48 ])
	
	weight_matrixA = []
	bias_matrixA = []
	full_matrixA = []

        def loadModel(subdir,weight_matrix,bias_matrix,index):
                w = np.load('../MODEL/'+subdir+'/w' + str(index) + '.npy')    
                waity = tf.constant(w, shape=list(w.shape))          
                b = np.load('../MODEL/'+subdir+'/b' + str(index) + '.npy')    
                biasy = tf.constant(b, shape=list(b.shape))          
                weight_matrix.append(waity)                          
                bias_matrix.append(biasy)                            


	for i in range(3):
		loadModel('0',weight_matrixA,bias_matrixA,i)
	
	fullsA = len(weight_matrixA) 

	full_matrixA.append(x)

	for i in range(fullsA-1):
		mm = tf.matmul( full_matrixA[i], weight_matrixA[i] )
		hv = tf.nn.tanh( mm + bias_matrixA[i])
		full_matrixA.append(hv)
	
	i = fullsA-1		
	mm = tf.matmul( full_matrixA[i], weight_matrixA[i] )
	y_a = tf.nn.tanh( mm + bias_matrixA[i] )
	
	init = tf.initialize_all_variables()

sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True))
sess.run(init)

(y_a) = sess.run([y_a], feed_dict= {  x: X  } )
y = np.clip(((y_a[0] + 0.5) * 96.0), 0, 96).astype(np.int)
np.save('../../../DATA/A_Clean_Train_Y_HAT.npy', y)
print y
print 'afinit'
sess.close()
print 'finito'
	
