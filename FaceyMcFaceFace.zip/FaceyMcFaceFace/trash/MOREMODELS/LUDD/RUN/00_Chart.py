import numpy as np
from matplotlib import pyplot as plt

off = 2
TRAIN_COST = np.load('../MODEL/0/TCost.npy')[off:]
VALID_COST = np.load('../MODEL/0/VCost.npy')[off:]
REGR_COST = np.load('../MODEL/0/RCost.npy')[off:] 
TRAIN_COST = TRAIN_COST - REGR_COST
VALID_COST = VALID_COST - REGR_COST

TRAIN_COST = ((TRAIN_COST**0.5) * 95.0).reshape((TRAIN_COST.shape[0],1))
VALID_COST = ((VALID_COST**0.5) * 95.0).reshape((VALID_COST.shape[0],1))

EPOC = list(range(TRAIN_COST.shape[0]))
print np.min(VALID_COST)

plt.plot(EPOC,TRAIN_COST, marker='^',c='b',lw='1',ls='none',label='Train')
plt.plot(EPOC,VALID_COST, marker='o', c='g', lw='1',ls='none',label='Valid')

plt.title('Learning Curves')
plt.legend()
plt.ylabel('MSQE')
plt.xlabel('EPOC')
plt.show()
