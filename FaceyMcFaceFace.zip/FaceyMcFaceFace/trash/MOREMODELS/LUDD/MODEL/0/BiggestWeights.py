import numpy as np

for i in range(10):
	v = np.load('w'+str(i)+'.npy')
	v = v*1000
	v = v**2
	s = np.sum(np.sum(v))
	a = s/(v.shape[0] * v.shape[1] * v.shape[2])
	print str(int(s)) + ':' + str(int(a)) + ':' + str(i)


