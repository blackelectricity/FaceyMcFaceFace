import sys
sys.path.insert(0, '../../../HELPER')
import IMSHOW

import tensorflow as tf
import numpy as np
XF = np.load('../../../DATA/testXval.npy')
XVF = np.load('../../../DATA/testXvalSHRINK.npy')
XV = np.load('../../../DATA/testXvalHOG.npy')

with tf.device('/gpu:0'):
	x  = tf.placeholder(tf.float32, shape=[ None, 48*48 ])
	x2 = tf.placeholder(tf.float32, shape=[ None, 48*48 ])
	x_image2 = tf.reshape(x2, [-1,48,48,1])
	#x_image = tf.reshape(x, [-1,24,32,3])	
	weight_matrix = []
	bias_matrix = []
	full_matrix = []
	conv_matrix = []	
	index = -1


	def loadModel():
		global index
		global bias_matrix
		global weight_matrix
		index += 1
		w = np.load('../MODEL/w' + str(index) + '.npy')
		waity = tf.constant(w, shape=list(w.shape))
		b = np.load('../MODEL/b' + str(index) + '.npy')
		biasy = tf.constant(b, shape=list(b.shape)) 
		weight_matrix.append(waity)
		bias_matrix.append(biasy)

	def tanconv(logit,shapeypoo,nummy):
		x = tf.nn.conv2d(logit,weight_matrix[nummy],strides=shapeypoo,padding='SAME')  
		x = tf.add(x, bias_matrix[nummy])
		return tf.nn.tanh(x)

	def poolio(logit, shapeypoo):
		return tf.nn.max_pool(logit,ksize=shapeypoo,strides=shapeypoo,padding='SAME')

	#FULLY CONNECTED LAYERS
	for i in range(0,3):
		loadModel()

	convs = 1
	dimmy = ((48*48)/((2*2)**convs))*100
	fulls = len(weight_matrix)  - convs
	#xp_image = tf.nn.avg_pool(x_image, ksize=[1,4,4,1], strides=[1,4,4,1], padding='SAME')
	conv_matrix.append(x_image2)
	for i in range(convs):
		cm = conv_matrix[i]
		tc = tanconv(cm, [1,1,1,1], i)
		pc = poolio(tc, [1,2,2,1])
		conv_matrix.append(pc)	
	
	reshaped = tf.reshape(conv_matrix[convs], [-1,dimmy])
	concatt = tf.concat(1, [reshaped, x])
	full_matrix.append(concatt)

	#full_matrix.append(tf.reshape(conv_matrix[convs], [-1,dimmy]))
	for i in range(fulls-1):
		mm = tf.matmul( full_matrix[i], weight_matrix[i+convs] )
		hv = tf.nn.tanh( mm + bias_matrix[i+convs])
		full_matrix.append(hv)

	#LAST LAYER NEVER DROPOUT 
	i = fulls-1		
	mm = tf.matmul( full_matrix[i], weight_matrix[i+convs] )
	y_ = tf.nn.tanh( mm + bias_matrix[i+convs] )

	init = tf.initialize_all_variables()

sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True))
sess.run(init)

(YV_) = sess.run([y_], feed_dict={ x: XV, x2: XVF })
print len(YV_)

for i in range(0,10):
	IMSHOW.ShowWithFeature(XF[i], YV_[0][i])

print 'afinit'
sess.close()
print 'finito'
	
