import sys
sys.path.insert(0, '../../../HELPER')
import IMSHOW
import pandas as pd
import tensorflow as tf
import numpy as np
XF = np.load('../../../DATA/testXval.npy')
XVF = np.load('../../../DATA/testXvalSHRINK.npy')
XV = np.load('../../../DATA/testXvalHOG.npy')
IDS = pd.read_csv('../../../DATA/id.csv')
ids = IDS.ix[:,1:3].values.reshape(-1,2)
refs = ['left_eye_center_x',
'left_eye_center_y',
'right_eye_center_x',
'right_eye_center_y',
'left_eye_inner_corner_x',
'left_eye_inner_corner_y',
'left_eye_outer_corner_x',
'left_eye_outer_corner_y',
'right_eye_inner_corner_x',
'right_eye_inner_corner_y',
'right_eye_outer_corner_x',
'right_eye_outer_corner_y',
'left_eyebrow_inner_end_x',
'left_eyebrow_inner_end_y',
'left_eyebrow_outer_end_x',
'left_eyebrow_outer_end_y',
'right_eyebrow_inner_end_x',
'right_eyebrow_inner_end_y',
'right_eyebrow_outer_end_x',
'right_eyebrow_outer_end_y',
'nose_tip_x',
'nose_tip_y',
'mouth_left_corner_x',
'mouth_left_corner_y',
'mouth_right_corner_x',
'mouth_right_corner_y',
'mouth_center_top_lip_x',
'mouth_center_top_lip_y',
'mouth_center_bottom_lip_x',
'mouth_center_bottom_lip_y']

idref = map(lambda val: [val[0],refs.index(val[1])], ids)

with tf.device('/gpu:0'):
	x  = tf.placeholder(tf.float32, shape=[ None, 48*48 ])
	x2 = tf.placeholder(tf.float32, shape=[ None, 48*48 ])
	x_image2 = tf.reshape(x2, [-1,48,48,1])
	#x_image = tf.reshape(x, [-1,24,32,3])	
	weight_matrix = []
	bias_matrix = []
	full_matrix = []
	conv_matrix = []	
	index = -1


	def loadModel():
		global index
		global bias_matrix
		global weight_matrix
		index += 1
		w = np.load('../MODEL/w' + str(index) + '.npy')
		waity = tf.constant(w, shape=list(w.shape))
		b = np.load('../MODEL/b' + str(index) + '.npy')
		biasy = tf.constant(b, shape=list(b.shape)) 
		weight_matrix.append(waity)
		bias_matrix.append(biasy)

	def tanconv(logit,shapeypoo,nummy):
		x = tf.nn.conv2d(logit,weight_matrix[nummy],strides=shapeypoo,padding='SAME')  
		x = tf.add(x, bias_matrix[nummy])
		return tf.nn.tanh(x)

	def poolio(logit, shapeypoo):
		return tf.nn.max_pool(logit,ksize=shapeypoo,strides=shapeypoo,padding='SAME')

	#FULLY CONNECTED LAYERS
	for i in range(0,3):
		loadModel()

	convs = 1
	dimmy = ((48*48)/((2*2)**convs))*100
	fulls = len(weight_matrix)  - convs
	#xp_image = tf.nn.avg_pool(x_image, ksize=[1,4,4,1], strides=[1,4,4,1], padding='SAME')
	conv_matrix.append(x_image2)
	for i in range(convs):
		cm = conv_matrix[i]
		tc = tanconv(cm, [1,1,1,1], i)
		pc = poolio(tc, [1,2,2,1])
		conv_matrix.append(pc)	
	
	reshaped = tf.reshape(conv_matrix[convs], [-1,dimmy])
	concatt = tf.concat(1, [reshaped, x])
	full_matrix.append(concatt)

	#full_matrix.append(tf.reshape(conv_matrix[convs], [-1,dimmy]))
	for i in range(fulls-1):
		mm = tf.matmul( full_matrix[i], weight_matrix[i+convs] )
		hv = tf.nn.tanh( mm + bias_matrix[i+convs])
		full_matrix.append(hv)

	#LAST LAYER NEVER DROPOUT 
	i = fulls-1		
	mm = tf.matmul( full_matrix[i], weight_matrix[i+convs] )
	y_ = tf.nn.tanh( mm + bias_matrix[i+convs] )

	init = tf.initialize_all_variables()

sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True))
sess.run(init)

(YV_) = sess.run([y_], feed_dict={ x: XV, x2: XVF })
counter = 1
f = open('submission.csv','w')
f.write('RowId,Location\n')
for i in range(len(idref)):
	image = idref[i][0] - 1
	feat = idref[i][1]
	location = int(np.clip(((YV_[0][image][feat]+0.5)*95.0), 0, 95))
	stringy = str(counter) + ',' + str(location) + '\n'
	f.write(stringy)
	counter = counter + 1

f.close()
print 'afinit'
sess.close()
print 'finito'
	
