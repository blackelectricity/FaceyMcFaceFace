import tensorflow as tf
import numpy as np

epocs = 30500
prins = 15
saves = 30
tlambda = 0.0001
l2val = 0.02
miniVAL = 10000000.0
patience = 90
cur_pat = 0
dropout = 0.4
batch_size = 1000

XT = np.load('../../../DATA/XtrainSHRINK.npy')
XV = np.load('../../../DATA/XvalSHRINK.npy')

YT = np.load('../../../DATA/Ytrain.npy')
YV = np.load('../../../DATA/Yval.npy')

print XT.shape, YT.shape, XV.shape, YV.shape

TRAIN_COST = []
VALID_COST = []

with tf.device('/gpu:0'):
	x  = tf.placeholder(tf.float32, shape=[ None, 48*48 ])
	x_image = tf.reshape(x, [-1, 48, 48, 1] )
	y  = tf.placeholder(tf.float32, shape=[ None, 8 ])
	
	seedy = 654321

	weight_matrix = []
	bias_matrix = []
	conv_matrix = []
	full_matrix = []

	def trunv(shape):
		global seedy
		seedy+=1
		return tf.Variable(tf.truncated_normal(shape,mean=-0.0001,stddev=0.01,seed=seedy))

	def vary(shape):
		global bias_matrix
		global weight_matrix
		waity = trunv(shape)	
		lenny = len(shape)
		bilen = shape[lenny-1]
		biasy = trunv([bilen])
		weight_matrix.append(waity)
		bias_matrix.append(biasy)

	def tanconv(logit,shapeypoo,nummy):
		x = tf.nn.conv2d(logit,weight_matrix[nummy],strides=shapeypoo,padding='SAME')  
		x = tf.add(x, bias_matrix[nummy])
		return tf.nn.tanh(x)

        def poolio(logit, shapeypoo):
                  return tf.nn.max_pool(logit,ksize=shapeypoo,strides=shapeypoo,padding='SAME')


	#CONV LAYERS
	vary([18,18,1,100])

	convs = len(weight_matrix)

	#FULLY CONNECTED LAYERS
	dimmy = ((48*48)/((2*2)**convs))*100
	vary([dimmy,40])
	vary([40,8])


	fulls = len(weight_matrix)  - convs
	#xp_image = tf.nn.avg_pool(x_image, ksize=[1,2,2,1], strides=[1,2,2,1], padding='SAME')
	conv_matrix.append(x_image)
	for i in range(convs):
		cm = conv_matrix[i]
		tc = tanconv(cm, [1,1,1,1], i)
		pc = poolio(tc, [1,2,2,1])
		conv_matrix.append(pc)	

	full_matrix.append(tf.reshape(conv_matrix[convs], [-1,dimmy]))
	for i in range(fulls-1):
		mm = tf.matmul( full_matrix[i], weight_matrix[i+convs] )
		hv = tf.nn.tanh( mm + bias_matrix[i+convs])
		#	do = tf.nn.dropout(hv,1-dropout)
		full_matrix.append(hv)

	#LAST LAYER NEVER DROPOUT 
	i = fulls-1		
	mm = tf.matmul( full_matrix[i], weight_matrix[i+convs] )
	y_ = tf.nn.tanh( mm + bias_matrix[i+convs] )
	cost = tf.reduce_mean(tf.square(tf.sub(y_,y)))

	regn = 0.0
	tots = len(weight_matrix)	
	for wix in range(tots):
		regn = regn + tf.reduce_mean(tf.square(weight_matrix[wix]))
		regn = regn + tf.reduce_mean(tf.square(bias_matrix[wix]))
	regn = regn / (tots * 2)
	cost = cost + (20 * regn)
		
	train_step = tf.train.AdamOptimizer(tlambda).minimize(cost)
			
	init = tf.initialize_all_variables()

sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True))
sess.run(init)

def printTest(i,c):
	global miniVAL
	global cur_pat
	returnVal = False
	if (i%prins == 0):
		(costo) = sess.run([cost], feed_dict={ x: XV, y: YV }) #NEVER RUN train_step on Validation set
		if (costo[0] < miniVAL):
			miniVAL = costo[0]
			cur_pat = 0
			returnVal = True #NEW MINIMUM VALIDATION SCORE REACHED, RETURN TRUE SO SAVE WILL SAVE WEIGHTS	
		else:
			cur_pat += 1
		TRAIN_COST.append(c)
		VALID_COST.append(costo[0])
		print('i:' + str(i) + '\tC:'+"{:7.9f}".format(costo[0]) + '\tT:'+"{:7.9f}".format(c))

	return returnVal

def saveTest(i,v):
	if (i%saves == 0):
		np.save('../MODEL/TCost.npy', TRAIN_COST)
		np.save('../MODEL/VCost.npy', VALID_COST)
		print 'saved scores'
		if (v):	
			for i in range(len(weight_matrix)):
				np.save('../MODEL/w'+str(i)+'.npy',sess.run(weight_matrix[i]))
			for i in range(len(bias_matrix)):
				np.save('../MODEL/b'+str(i)+'.npy',sess.run(bias_matrix[i]))
			print 'saved weights'

BatchSize = batch_size
BatchIndex = -BatchSize
TotalSize = XT.shape[0]
def GetTrainBatch():
	global BatchIndex
	BatchIndex = BatchIndex + BatchSize 
	BatchIndex = BatchIndex % TotalSize
	if (BatchIndex + BatchSize > TotalSize):
		partA = XT[BatchIndex:].copy()
		partAy= YT[BatchIndex:].copy()
		partB = XT[0:((BatchIndex + BatchSize) - TotalSize)].copy()
		partBy= YT[0:((BatchIndex + BatchSize) - TotalSize)].copy()
		xt2 = np.vstack((partA,partB))
		yt2 = np.vstack((partAy,partBy))
		return (xt2,yt2)
	else:
		return (XT[BatchIndex:(BatchIndex + BatchSize)], YT[BatchIndex:(BatchIndex + BatchSize)])
		
VBatchSize = BatchSize + 1
VBatchIndex = -VBatchSize 
VTotalSize = XV.shape[0]
def GetValidBatch(): #UNUSED RIGHT NOW BECAUSE LESS MEMORY NEEDED FOR RUNNING VALIDATION
	global VBatchIndex
	VBatchIndex = VBatchIndex + VBatchSize 
	VBatchIndex = VBatchIndex % VTotalSize
	if (VBatchIndex + VBatchSize > VTotalSize):
		partA = XV[VBatchIndex:].copy()
		partAy= YV[VBatchIndex:].copy()
		partB = XV[:((VBatchIndex + VBatchSize) - VTotalSize)].copy()
		partBy= YV[:((VBatchIndex + VBatchSize) - VTotalSize)].copy()
		xt2 = np.vstack((partA,partB))
		yt2 = np.vstack((partAy,partBy))
		return (xt2,yt2)
	else:
		return (XV[VBatchIndex:(VBatchIndex + VBatchSize)], YV[VBatchIndex:(VBatchIndex + VBatchSize)])

for i in range(epocs+1):
	c = 0.0
	(xT,yT) = GetTrainBatch()
	if (i%prins == 0):
		(res,c,regr) = sess.run([train_step,cost,regn], feed_dict={ x: xT, y: yT  })
		print regr
	else:
		(res) = sess.run([train_step], feed_dict={ x: xT, y: yT  })
	v = printTest(i,c)
	saveTest(i,v)
	if (cur_pat > patience):
		print 'early stopping'
		break

print 'afinit'
sess.close()

print 'finito'
	
