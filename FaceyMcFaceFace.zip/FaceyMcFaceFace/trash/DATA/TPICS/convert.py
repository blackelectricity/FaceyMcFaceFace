import numpy as np
from PIL import Image

CVTEST = np.zeros((8,96*96))
for i in range(0,8,1):
	fname = str(i) + '.JPG'
	img = Image.open(fname).convert('L')
	#img = img.rotate(-90,expand=1)
	img = img.resize((96,96),Image.ANTIALIAS)
	idt = ((np.array(list(img.getdata())) / 255.0) - 0.5)
	CVTEST[i] = idt
	img = img.resize((300,300), Image.ANTIALIAS)
	img.show()

np.save('../cvtest.npy',CVTEST)




