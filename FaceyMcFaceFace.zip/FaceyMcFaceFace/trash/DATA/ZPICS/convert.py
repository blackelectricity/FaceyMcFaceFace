import numpy as np
from PIL import Image

CVTEST = np.zeros((8,96*96))
for i in range(8):
	fname = str(i) + '.JPG'
	img = Image.open(fname).convert('L')
	img = img.resize((96,96),Image.ANTIALIAS)
	idt = np.array(list(img.getdata()))
	CVTEST[i] = idt
	img = img.resize((300,300), Image.ANTIALIAS)
	img.show()

np.save('../X_valid.npy',CVTEST)




