import tensorflow as tf
import numpy as np

epocs = 1500
prins = 5
saves = 10
tlambda = 0.000001
l2val = 0.02
miniVAL = 10000000.0
patience = 10
cur_pat = 0
dropout = 0.002

XT = np.load('../DATA/Xtrain.npy')
XV = np.load('../DATA/Xval.npy')

YT = np.load('../DATA/Ytrain.npy')
YV = np.load('../DATA/Yval.npy')

TRAIN_COST = []
VALID_COST = []

with tf.device('/gpu:0'):
	x  = tf.placeholder(tf.float32, shape=[ None, 96*96 ])
	x_image = tf.reshape(x, [-1, 96, 96, 1] )
	y  = tf.placeholder(tf.float32, shape=[ None, 8 ])
	
	seedy = 654321

	weight_matrix = []
	bias_matrix = []
	conv_matrix = []
	full_matrix = []

	def trunv(shape):
		global seedy
		seedy+=1
		return tf.Variable(tf.truncated_normal(shape,mean=-0.0001,stddev=0.01,seed=seedy))

	def vary(shape):
		global bias_matrix
		global weight_matrix
		waity = trunv(shape)	
		lenny = len(shape)
		bilen = shape[lenny-1]
		biasy = trunv([bilen])
		weight_matrix.append(waity)
		bias_matrix.append(biasy)

	def tanconv(logit,shapeypoo,nummy):
		x = tf.nn.conv2d(logit,weight_matrix[nummy],strides=shapeypoo,padding='SAME')  
		x = tf.add(x, bias_matrix[nummy])
		return tf.nn.tanh(x)

        def poolio(logit, shapeypoo):
                  return tf.nn.max_pool(logit,ksize=shapeypoo,strides=shapeypoo,padding='SAME')


	#CONV LAYERS
	vary([3,3,1,16])
	vary([2,2,16,64])
	vary([2,2,64,256])
	vary([2,2,256,1024])

	convs = len(weight_matrix)

	#FULLY CONNECTED LAYERS
	dimmy = ((96*96/4)/((2*2)**convs))*1024
	vary([dimmy,576])
	vary([576,576])
	vary([576,576])
	vary([576,8])


	fulls = len(weight_matrix)  - convs
	xp_image = tf.nn.avg_pool(x_image, ksize=[1,2,2,1], strides=[1,2,2,1], padding='SAME')
	conv_matrix.append(xp_image)
	for i in range(convs):
		cm = conv_matrix[i]
		tc = tanconv(cm, [1,1,1,1], i)
		pc = poolio(tc, [1,2,2,1])
		conv_matrix.append(pc)	

	full_matrix.append(tf.reshape(conv_matrix[convs], [-1,dimmy]))
	for i in range(fulls-1):
		mm = tf.matmul( full_matrix[i], weight_matrix[i+convs] )
		hv = tf.nn.tanh( mm + bias_matrix[i+convs])
		do = tf.nn.dropout(hv,1-dropout)
		full_matrix.append(do)

	#LAST LAYER NEVER DROPOUT 
	i = fulls-1		
	mm = tf.matmul( full_matrix[i], weight_matrix[i+convs] )
	y_ = tf.nn.tanh( mm + bias_matrix[i+convs] )
	cost = tf.reduce_mean(tf.square(tf.sub(y_,y)))
	
	train_step = tf.train.AdamOptimizer(tlambda).minimize(cost)
			
	init = tf.initialize_all_variables()

sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True))
sess.run(init)

def printTest(i,c):
	global miniVAL
	global cur_pat
	returnVal = False
	if (i%prins == 0):
		(costo) = sess.run([cost], feed_dict={ x: XV, y: YV }) #NEVER RUN train_step on Validation set
		if (costo[0] < miniVAL):
			miniVAL = costo[0]
			cur_pat = 0
			returnVal = True #NEW MINIMUM VALIDATION SCORE REACHED, RETURN TRUE SO SAVE WILL SAVE WEIGHTS	
		else:
			cur_pat += 1
		TRAIN_COST.append(c)
		VALID_COST.append(costo[0])
		print('i:' + str(i) + '\tC:'+"{:7.9f}".format(costo[0]) + '\tT:'+"{:7.9f}".format(c))

	return returnVal

def saveTest(i,v):
	if (i%saves == 0):
		np.save('../MODEL/TCost.npy', TRAIN_COST)
		np.save('../MODEL/VCost.npy', VALID_COST)
		print 'saved scores'
		if (v):	
			for i in range(len(weight_matrix)):
				np.save('../MODEL/w'+str(i)+'.npy',sess.run(weight_matrix[i]))
			for i in range(len(bias_matrix)):
				np.save('../MODEL/b'+str(i)+'.npy',sess.run(bias_matrix[i]))
			print 'saved weights'

for i in range(epocs+1):
	c = 0.0
	if (i%prins == 0):
		(res,c) = sess.run([train_step,cost], feed_dict={ x: XT, y: YT  })
	else:
		(res) = sess.run([train_step], feed_dict={ x: XT, y: YT  })
	v = printTest(i,c)
	saveTest(i,v)
	if (cur_pat > patience):
		print 'early stopping'
		break

print 'afinit'
sess.close()

print 'finito'
	
