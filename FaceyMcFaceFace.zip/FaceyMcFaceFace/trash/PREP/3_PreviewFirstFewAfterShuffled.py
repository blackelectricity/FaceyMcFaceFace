import sys
sys.path.insert(0, '../HELPER')
import IMSHOW

import numpy as np
from PIL import Image
from math import floor


x = np.load('../DATA/Xval.npy')
y = np.load('../DATA/Yval.npy')

for imageNum in range(0,10):
	IMSHOW.ShowWithFeature(x[imageNum],y[imageNum])


