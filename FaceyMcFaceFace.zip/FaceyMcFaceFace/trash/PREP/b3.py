import sys
sys.path.insert(0, '../HELPER')
import IMSHOW

import numpy as np
from PIL import Image
from math import floor


x = np.load('../DATA/testXval.npy')
print x.shape
for imageNum in range(0,10):
	z = x[imageNum].copy() + 0.5
	z = z * 255.0
	z = np.clip(z, 0, 255).astype(np.uint8)
	z = z.reshape((96,96))
	i = Image.fromarray(z, 'L') 
	i.show()


