import sys
sys.path.insert(0, '../HELPER')
import IMSHOW

import numpy as np
from PIL import Image
from math import floor


x = (np.load('../DATA/Xclean.npy') / 255.0) -0.5
y = (np.load('../DATA/yclean.npy') / 95.0) - 0.5

for imageNum in range(0,10):
	IMSHOW.ShowWithFeature(x[imageNum],y[imageNum])


