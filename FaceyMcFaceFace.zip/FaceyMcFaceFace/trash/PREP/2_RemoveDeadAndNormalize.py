import numpy as np

def RemoveDeadRows(X,Y):
	Y = Y.astype(np.float)
	rows = []
	for index in range(Y.shape[0]):
		boolio = (np.isnan(Y[index])).astype(np.int)
		tots = np.sum(boolio)
		if (tots > 0): 
			rows.append(index)
	Y = np.delete(Y,rows,0)
	X = np.delete(X,rows,0)
	return (X,Y)	

def NormalizeX(xin):
	xmin = np.min(xin)
	xin = xin - xmin
	xmax = np.max(xin)
	xin = xin / (xmax + 0.00000000001)
	xmean = np.mean(xin)
	xin = xin - xmean	
	return xin

def NormalizeY(yin):
	return ((yin / 96.0) - 0.5)

def Normalize(xin,yin):
	xin = NormalizeX(xin) 
	yin = NormalizeY(yin)
	return (xin,yin)

def CleanArrays(XIN,YIN,XOUT,YOUT):
	print XIN,YIN
	xin = np.load('../DATA/' + XIN + '.npy')
	yin = np.load('../DATA/' + YIN + '.npy')
	print xin.shape, yin.shape
	(xin, yin) = RemoveDeadRows(xin,yin)
	print xin.shape, yin.shape
	(xin, yin) = Normalize(xin,yin)
	np.save('../DATA/' + XOUT + '.npy', xin)
	np.save('../DATA/' + YOUT + '.npy', yin)
	print XOUT, YOUT
	print '--------'


print 'START FULL CLEAN'
CleanArrays('fullX','fullYa','A_Clean_Full_X','A_Clean_Full_Y')
CleanArrays('fullX','fullYb','B_Clean_Full_X','B_Clean_Full_Y')

print 'START TRAIN CLEAN'
CleanArrays('trainX','trainYa','A_Clean_Train_X','A_Clean_Train_Y')
CleanArrays('trainX','trainYb','B_Clean_Train_X','B_Clean_Train_Y')

print 'START CROSS CLEAN'
CleanArrays('crossX','crossYa','A_Clean_Cross_X','A_Clean_Cross_Y')
CleanArrays('crossX','crossYb','B_Clean_Cross_X','B_Clean_Cross_Y')

print 'CLEAN TEST X'
testX = np.load('../DATA/testX.npy')
testX = NormalizeX(testX)
np.save('../DATA/F_Clean_Test_X.npy',testX)

print 'CLEAN VALID X'
validX = np.load('../DATA/validX.npy')
validX = NormalizeX(validX)
np.save('../DATA/F_Clean_Valid_X.npy',validX)

print 'DONE'
