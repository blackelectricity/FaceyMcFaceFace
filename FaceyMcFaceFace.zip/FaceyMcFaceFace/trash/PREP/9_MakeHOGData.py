import numpy as np
from PIL import Image
from skimage.feature import hog

def SHRINK(XNAME):
	x = np.load('../DATA/' + XNAME + '_X.npy')
	print x.shape
	x = x.reshape((x.shape[0], 96, 96))
	x2 = np.zeros((x.shape[0], 48 * 48))
	xmin = np.min(x)
	x = x - xmin
	xmax = np.max(x)
	x = x / (xmax + 0.0000000000001)
	x = (x * 255.0).astype(np.uint8)	
	for i in range(x.shape[0]):
		rx = x[i].copy()
		hogi = hog(rx, orientations=3,pixels_per_cell=(3,4), cells_per_block=(1,1))
		hmin = np.min(hogi)
		hogi = hogi - hmin
		hmax = np.max(hogi)
		hogi = hogi / (hmax + 0.0000000001)
		havg = np.mean(hogi)
		hogi = hogi - havg 
		x2[i] = hogi.copy() 
	np.save('../DATA/' + XNAME + '_X_HOG.npy', x2)

def AShrink(xarrays):
	for ar in xarrays:
		print 'start: ' + ar
		SHRINK(ar)
		print ar + ' is done'
		print '------'

print 'STARTING'
	
AShrink([ \
	'A_Clean_Full', \
	'B_Clean_Full', \
	'A_Clean_Train', \
	'B_Clean_Train', \
	'A_Clean_Cross', \
	'B_Clean_Cross', \
	'F_Clean_Test', \
	'F_Clean_Valid', \
	])
	

print 'DONE'
