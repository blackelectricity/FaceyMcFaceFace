import sys
sys.path.insert(0, '../HELPER')
import IMSHOW as ims
import numpy as np
from PIL import Image
from math import sqrt

def prev(XNAME, hasY):
	x = np.load('../DATA/' + XNAME + '_X_SHRINK.npy')
	xs = np.load('../DATA/' + XNAME + '_X_SHRINK_DUB.npy')
	wh = int(sqrt(x.shape[1]))
	wh2 = int(sqrt(xs.shape[1]))
	print wh, wh2
	for i in range(2):
		if (not(hasY)):
			ims.Show(x[i],wh,wh)
			ims.Show(xs[i],wh2,wh2)
		else:
			y = np.load('../DATA/' + XNAME + '_Y.npy')
			y2 = np.load('../DATA/' + XNAME + '_Y_DUB.npy')
			ims.ShowWithFeature(x[i],y[i],wh,wh)
			ims.ShowWithFeature(xs[i],y2[i],wh2,wh2)

def Preview(xarrays,hasY):
	for ar in xarrays:
		print 'start: ' + ar
		prev(ar,hasY)
		print ar + ' is done'
		print '------'
		raw_input()

print 'STARTING'
	
Preview([ \
	'A_Clean_Train', \
	'B_Clean_Train', \
	],True)

print 'DONE'
