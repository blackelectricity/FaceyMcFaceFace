import numpy as np
from math import floor

print 'LOAD'
x = np.load('../DATA/Xclean.npy')
y = np.load('../DATA/yclean.npy')

print 'NORMALIZE'
x = ( ( x / 255.0 ) - 0.5 )
y = ( ( y / 95.0 ) - 0.5 ) 

print 'STACK'
xlen = x.shape[1]
XY = np.hstack((x,y))
full = XY.shape[0]
tnty = int(floor(float(full) * 0.15))
eity = full - tnty

print 'SHUFFLE'
np.random.shuffle(XY)

print 'SPLIT TRAIN/VAL'
XYTrain = XY.copy()
XYVal = XY[eity:,:].copy()
XY = None

print 'SPLICE X/Y'
XTrain = XYTrain[:,:xlen]
YTrain = XYTrain[:,xlen:]
XVal = XYVal[:,:xlen]
YVal = XYVal[:,xlen:]

print 'SAVE'
print XTrain.shape
print YTrain.shape
print XVal.shape
print YVal.shape

np.save('../DATA/Xtrain.npy',XTrain)
np.save('../DATA/Xval.npy', XVal)
np.save('../DATA/Ytrain.npy',YTrain)
np.save('../DATA/Yval.npy', YVal)

print 'DONE'

