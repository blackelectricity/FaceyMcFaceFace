import sys
sys.path.insert(0, '../HELPER')
import IMSHOW as ims
import numpy as np
from PIL import Image
from math import sqrt

def prev(XNAME, hasY):
	x = np.load('../DATA/' + XNAME + '_X.npy')
	xs = np.load('../DATA/' + XNAME + '_X_SHRINK.npy')
	wh = int(sqrt(x.shape[1]))
	wh2 = int(sqrt(xs.shape[1]))
	print wh, wh2
	if (not(hasY)):
		ims.Show(x[0],wh,wh)
		ims.Show(xs[0],wh2,wh2)
	else:
		y = np.load('../DATA/' + XNAME + '_Y.npy')
		ims.ShowWithFeature(x[0],y[0],wh,wh)
		ims.ShowWithFeature(xs[0],y[0],wh2,wh2)

def Preview(xarrays,hasY):
	for ar in xarrays:
		print 'start: ' + ar
		prev(ar,hasY)
		print ar + ' is done'
		print '------'
		raw_input()

print 'STARTING'
	
Preview([ \
	'A_Clean_Full', \
	'B_Clean_Full', \
	'A_Clean_Train', \
	'B_Clean_Train', \
	'A_Clean_Cross', \
	'B_Clean_Cross', \
	],True)

Preview([ \
	'F_Clean_Test', \
	'F_Clean_Valid', \
	],False)
	

print 'DONE'
