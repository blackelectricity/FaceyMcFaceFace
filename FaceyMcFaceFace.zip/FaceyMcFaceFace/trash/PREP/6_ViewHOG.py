import sys
sys.path.insert(0, '../HELPER')
import IMSHOW as im
from PIL import Image
from math import floor,sqrt
import numpy as np
from skimage.feature import hog

def GetReshape(xf):
	x0 = xf.copy()
	x0m = np.min(x0)
	x0 = x0 - x0m
	x0m = np.max(x0)
	x0 = x0 / x0m
	x0 = x0 * 255.0
	x0 = np.clip(x0, 0, 255)
	x0 = x0.reshape((96,96))
	return x0

def GetHOG(xf):
	x0 = xf.copy()# / 255.0
	hogi = hog(x0,orientations=3,pixels_per_cell=(3,4), cells_per_block=(1,1))#,visualise=True)
	#hogi = hogi.flatten()
	#print hogd.shape
	#sizewh = int(sqrt(hogi.shape[0]))
	hmin = np.min(hogi)
	hogi = hogi - hmin
	hmax = np.max(hogi)
	hogi = hogi / hmax
	hogi = hogi - 0.5
	#hogi = hogi * 255.0
	#hogi = np.clip(hogi, 0, 255)
	#im.Show(hogi, sizewh, sizewh)
	#hogi = GetSmallerVersion(hogi.reshape((sizewh,sizewh)))
	return hogi		


def GetSmallerVersion(xf):
	x0 = xf.copy()
	im1 = Image.fromarray(x0.astype(np.uint8),'L')
	im1 = im1.resize((17,17), Image.ANTIALIAS)
	x0 = np.array(list(im1.getdata()))
	x0 = x0 / 255.0
	x0 = x0 - 0.5
	return x0
	
Xv = np.load('../DATA/XvalHOG.npy')
Xf = np.load('../DATA/Xval.npy')

for inx in range(5):
	xvo = ( Xv[inx] + 0.5 ) * 255.0
	xvo = np.clip(xvo, 0, 255)
	one = xvo.reshape((24,32,3))
	ones = one[:,:,2].reshape((24,32))
	im1 = Image.fromarray(ones.astype(np.uint8),'L')
	im1 = im1.resize((200,200), Image.ANTIALIAS)
	im1.show()
	axvo = ( Xf[inx] + 0.5 ) * 255.0
	axvo = np.clip(axvo, 0, 255)
	aones = axvo.reshape((96,96))
	aim1 = Image.fromarray(aones.astype(np.uint8),'L')
	aim1 = aim1.resize((200,200))
	aim1.show()

