import numpy as np

x = np.load('../DATA/X.npy')
y = np.load('../DATA/y.npy')

#cols = []
#for index in range(0,y.shape[1]):
#	boolio =  np.isnan(y[:,index])
#tots = np.sum(boolio.astype(np.int))
#if (tots > 100):
#cols.append(index)
#y = np.delete(y, cols, 1)

rows = []
counter = np.zeros((1,y.shape[1]))
for index in range(0,y.shape[0]):
	boolio = np.isnan(y[index,:])
	ioolio = boolio.astype(np.int)	
	counter = np.add(counter, ioolio.reshape(1,y.shape[1]))
	tots = np.sum(ioolio)
	if (tots > 0):
		rows.append(index)

y = np.delete(y,rows,0)
x = np.delete(x,rows,0)
np.save('../DATA/Xclean.npy',x)
np.save('../DATA/yclean.npy',y)
