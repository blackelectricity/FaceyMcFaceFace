import numpy as np
from PIL import Image

def SHRINK(XNAME,YNAME):
	x = np.load('../DATA/' + XNAME + '.npy' )
	xr = x.reshape((x.shape[0], 48, 48))	
	
	y = np.load('../DATA/' + YNAME + '.npy' )
	print y[3,4:6]

	yr = y.copy().reshape((y.shape[0], y.shape[1] / 2, 2 ))
	yr[:,:,0] = yr[:,:,0] * -1
	yr = yr.reshape((y.shape[0], y.shape[1]))

	print y[3,4:6]
	print yr[3,4:6]

	x2 = np.zeros((x.shape[0]*2, x.shape[1]))
	y2 = np.zeros((y.shape[0]*2, y.shape[1]))

	xmin = np.min(xr)
	xr = xr - xmin
	xmax = np.max(xr)
	xr = xr / (xmax + 0.0000000000001)
	xr = (xr * 255.0).astype(np.uint8)	
	for i in range(x.shape[0]):
		rx = xr[i].copy()
		im = Image.fromarray(rx, 'L')
		im = im.transpose(Image.FLIP_LEFT_RIGHT)
		idd = np.array(list(im.getdata())).astype(np.float)
		idmin = np.min(idd)
		idd = idd - idmin
		idmax = np.max(idd)
		idd = idd / (idmax + 0.00000000001)
		idavg = np.mean(idd)
		idd = idd - idavg	
		x2[(i*2)] = idd.copy()
		y2[(i*2)] = yr[i].copy()
		
		x2[(i*2) + 1] = x[i].copy()
		y2[(i*2) + 1] = y[i].copy()	

	print 'shuffle'
	concat = np.hstack((x2,y2))
	np.random.shuffle(concat)

	print 'splice'
	x2 = concat[:,:x.shape[1]].copy()
	y2 = concat[:,x.shape[1]:].copy()	
	
	print 'save'
	np.save('../DATA/' + XNAME + '_DUB.npy',x2)
	np.save('../DATA/' + YNAME + '_DUB.npy',y2)

def AShrink(xarrays):
	for (ar,yr) in xarrays:
		print 'start: ' + ar
		SHRINK(ar,yr)
		print ar + ' is done'
		print '------'

print 'STARTING'
	
AShrink([ \
	('A_Clean_Train_X_SHRINK','A_Clean_Train_Y'), \
	('B_Clean_Train_X_SHRINK','B_Clean_Train_Y') \
	])
	

print 'DONE'
