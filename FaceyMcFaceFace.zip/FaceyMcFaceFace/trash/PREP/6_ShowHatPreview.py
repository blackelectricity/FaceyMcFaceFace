import sys
sys.path.insert(0, '../HELPER')
import IMSHOW as ims
import numpy as np	

x = np.load('../DATA/A_Clean_Train_X.npy')
y = np.load('../DATA/A_Clean_Train_Y.npy')
axhat = np.load('../DATA/A_Clean_Train_X_HAT.npy')[0,:,0:24*24].copy()
for feat in axhat:
	ims.Show(feat, 24, 24)

print axhat.shape
ims.ShowWithFeature(x[0],y[0],96,96)

x = np.load('../DATA/B_Clean_Train_X.npy')
y = np.load('../DATA/B_Clean_Train_Y.npy')
axhat = np.load('../DATA/B_Clean_Train_X_HAT.npy')[0,:,0:24*24].copy()
for feat in axhat:
	ims.Show(feat, 24, 24)

print axhat.shape
ims.ShowWithFeature(x[0],y[0],96,96)
