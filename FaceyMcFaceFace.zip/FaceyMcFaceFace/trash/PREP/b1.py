import numpy as np

x = np.load('../DATA/testX.npy')

#cols = []
#for index in range(0,y.shape[1]):
#	boolio =  np.isnan(y[:,index])
#tots = np.sum(boolio.astype(np.int))
#if (tots > 100):
#cols.append(index)
#y = np.delete(y, cols, 1)

np.save('../DATA/testXclean.npy',x)
