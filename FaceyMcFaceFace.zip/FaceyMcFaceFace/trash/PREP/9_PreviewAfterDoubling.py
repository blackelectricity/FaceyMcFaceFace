import sys
sys.path.insert(0, '../HELPER')
import IMSHOW

import numpy as np
from PIL import Image
from math import floor


x = np.load('../DATA/XtrainSHRINK2.npy')
x2 = np.load('../DATA/XtrainHOG2.npy')
y = np.load('../DATA/Ytrain2.npy')


for inx in range(5):
	xvo = ( x2[inx] + 0.5 ) * 255.0
	xvo = np.clip(xvo, 0, 255)
	one = xvo.reshape((24,32,3))
	ones = one[:,:,2].reshape((24,32))
	im1 = Image.fromarray(ones.astype(np.uint8),'L')
	im1 = im1.resize((96,96), Image.ANTIALIAS)
	im1d = (np.array(list(im1.getdata())) / 255.0 - 0.5)
	IMSHOW.ShowWithFeature(im1d,y[inx])	
	axvo = ( x[inx] + 0.5 ) * 255.0
	axvo = np.clip(axvo, 0, 255)
	aones = axvo.reshape((48,48))
	aim1 = Image.fromarray(aones.astype(np.uint8),'L')
	aim1 = aim1.resize((96,96), Image.ANTIALIAS)
	aim1d = (np.array(list(aim1.getdata())) / 255.0 - 0.5)
	IMSHOW.ShowWithFeature(aim1d,y[inx])	

