import numpy as np
from PIL import Image
from skimage.feature import hog

def SHRINK(XNAME):
	x = np.load('../DATA/' + XNAME + '_Y.npy')
	x = x.reshape((x.shape[0], 11, 2))
	regx = ((x[:,:,0].copy() + 0.5 ) * 96).reshape((x.shape[0],11))
	regy = ((x[:,:,1].copy() + 0.5 ) * 96).reshape((x.shape[0],11))
	scale = 96.0 / 12.0
	x2 = np.zeros((x.shape[0], 12,12, 22))
	for ix in range(12):
		for iy in range(12):
			nx = regx.copy() - (ix * scale)
			ny = regy.copy() - (iy * scale)
			for iz in range(11):
				x2[:, ix,iy, iz*2 ] = x2[:, ix,iy, iz*2 ] + nx[:,iz]
				x2[:, ix,iy, iz*2 + 1] = x2[:, ix,iy,iz*2+1] + ny[:,iz]
	x2 = x2 / 96.0			
	np.save('../DATA/' + XNAME + '_Y_HOT.npy', x2)

def AShrink(xarrays):
	for ar in xarrays:
		print 'start: ' + ar
		SHRINK(ar)
		print ar + ' is done'
		print '------'

print 'STARTING'
	
AShrink([ \
	'B_Clean_Full', \
	'B_Clean_Train', \
	'B_Clean_Cross' 
	])
	

print 'DONE'
