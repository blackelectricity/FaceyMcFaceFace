import numpy as np
from math import floor

print 'LOAD'
x = np.load('../DATA/testXclean.npy')

print 'NORMALIZE'
x = ( ( x / 255.0 ) - 0.5 )

print 'STACK'
np.save('../DATA/testXval.npy', x)

print 'DONE'

