import sys
sys.path.insert(0, '../HELPER')
import IMSHOW as im
from PIL import Image
from math import floor,sqrt
import numpy as np
from skimage.feature import hog

def GetReshape(xf):
	x0 = xf.copy()
	x0m = np.min(x0)
	x0 = x0 - x0m
	x0m = np.max(x0)
	x0 = x0 / x0m
	x0 = x0 * 255.0
	x0 = np.clip(x0, 0, 255)
	x0 = x0.reshape((96,96))
	return x0

def GetHOG(xf):
	x0 = xf.copy()# / 255.0
	hogi = hog(x0,orientations=3,pixels_per_cell=(3,4), cells_per_block=(1,1))#,visualise=True)
	#hogi = hogi.flatten()
	#print hogd.shape
	#sizewh = int(sqrt(hogi.shape[0]))
	hmin = np.min(hogi)
	hogi = hogi - hmin
	hmax = np.max(hogi)
	hogi = hogi / hmax
	hogi = hogi - 0.5
	#hogi = hogi * 255.0
	#hogi = np.clip(hogi, 0, 255)
	#im.Show(hogi, sizewh, sizewh)
	#hogi = GetSmallerVersion(hogi.reshape((sizewh,sizewh)))
	return hogi		


def GetSmallerVersion(xf):
	x0 = xf.copy()
	im1 = Image.fromarray(x0.astype(np.uint8),'L')
	im1 = im1.resize((17,17), Image.ANTIALIAS)
	x0 = np.array(list(im1.getdata()))
	x0 = x0 / 255.0
	x0 = x0 - 0.5
	return x0

def FLIPLR(array):
	reshaped = array.reshape((48,48))
	zerovf = np.fliplr(reshaped)
	zerovf = zerovf.flatten()
	return zerovf

Xt = np.load('../DATA/XtrainSHRINK.npy')
Xt2 = np.ones((Xt.shape[0]*2, Xt.shape[1]))

print 'start'
for xix in range(Xt.shape[0]):
	resx = Xt[xix].copy()
	Xt2[xix*2] = Xt[xix].copy() 
	Xt2[xix*2+1] = FLIPLR(resx)

print 'loop1'
print Xt2.shape
np.save('../DATA/XtrainSHRINK2.npy', Xt2)

print 'done'

