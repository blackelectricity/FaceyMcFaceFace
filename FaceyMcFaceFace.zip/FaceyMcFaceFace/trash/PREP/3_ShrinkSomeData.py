import numpy as np
from PIL import Image

def SHRINK(XNAME):
	x = np.load('../DATA/' + XNAME + '_X.npy')
	print x.shape
	x = x.reshape((x.shape[0], 96, 96))	
	x2 = np.zeros((x.shape[0], 48 * 48))
	xmin = np.min(x)
	x = x - xmin
	xmax = np.max(x)
	x = x / (xmax + 0.000000000000001)
	x = x * 255.0
	x = np.clip(x,0,255).astype(np.uint8)
	for i in range(x.shape[0]):
		rx = x[i].copy()
		im = Image.fromarray(rx, 'L')
		im = im.resize((48,48), Image.ANTIALIAS)
		idd =np.array(list(im.getdata())).astype(np.float)
		idmin = np.min(idd)
		idd = idd - idmin
		idmax = np.max(idd)
		idd = idd / (idmax + 0.00000000000000001)
		idavg = np.mean(idd)
		idd = idd - idavg
		x2[i] = idd
	np.save('../DATA/' + XNAME + '_X_SHRINK.npy', x2)

def AShrink(xarrays):
	for ar in xarrays:
		print 'start: ' + ar
		SHRINK(ar)
		print ar + ' is done'
		print '------'

print 'STARTING'
	
AShrink([ \
	'A_Clean_Full', \
	'B_Clean_Full', \
	'A_Clean_Train', \
	'B_Clean_Train', \
	'A_Clean_Cross', \
	'B_Clean_Cross', \
	'F_Clean_Test', \
	'F_Clean_Valid', \
	])
	

print 'DONE'
