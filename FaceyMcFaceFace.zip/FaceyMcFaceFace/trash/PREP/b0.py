import numpy as np
import pandas as pd

print 'STARTING'
F_INPUT  = '../DATA/test.csv'
F_OUTPUT_X = '../DATA/testX.npy'

print 'READING'
df = pd.read_csv(F_INPUT)

print 'FORMATTING'
df['Image'] = df['Image'].apply(lambda spacey: np.fromstring(spacey, sep=' '))

print 'SPLICING'
images = df.ix[:,-1:].values

print 'RESHAPING'
images = np.array(list(images[:,0]))

print 'SAVING X'
np.save(F_OUTPUT_X, images)

print 'FINISHED'


 
