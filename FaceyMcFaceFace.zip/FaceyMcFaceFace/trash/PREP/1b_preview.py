import sys
sys.path.insert(0, '../HELPER')
import IMSHOW as ims
import numpy as np
from PIL import Image
from math import sqrt

x = np.load('../DATA/fullX.npy') / 255.0 - 0.5
y = np.load('../DATA/fullYa.npy') / 95.0 - 0.5
yb =np.load('../DATA/fullYb.npy') / 95.0 - 0.5
print x.shape
print y.shape
print yb.shape
wh = int(sqrt(x.shape[1]))
for i in [1748, 1878, 2091,2200,1908]:
	if (np.sum(np.isnan(y[i].astype(np.float)).astype(np.int)) > 0):
		continue
		if (np.sum(np.isnan(yb[i].astype(np.float)).astype(np.int)) > 0):
			continue
		ims.ShowWithFeature(x[i],yb[i],wh,wh)
	else:
		if (np.sum(np.isnan(yb[i].astype(np.float)).astype(np.int)) > 0):
			ims.ShowWithFeature(x[i],y[i],wh,wh)	
		else:
			ims.ShowWithDoubleFeature(x[i],y[i],yb[i],wh,wh)

