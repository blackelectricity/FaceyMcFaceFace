import numpy as np
from math import floor

print 'LOADING'
xy_train = np.load('../DATA/XY_train.npy')
x_test = np.load('../DATA/X_test.npy')
x_valid = np.load('../DATA/X_valid.npy')

print 'SHUFFLE TRAINING SETS'
np.random.shuffle(xy_train)

print 'SPLIT OFF TRAINING CROSS VALIDATION'
twentyPercent = int(floor(xy_train.shape[0] * .2))
print str(twentyPercent) + '/' + str(xy_train.shape[0]) + ' =  20%'
xy_training_full = xy_train.copy()
xy_training = xy_train[:-twentyPercent,:].copy()
xy_cross = xy_train[-twentyPercent:,:].copy()
xy_train = None

print 'SPLIT OFF IMAGES training_full'
x_training_full = xy_training_full[:,-1:].copy()
y_training_full = xy_training_full[:,:-1].copy()
xy_training_full = None

print 'SPLIT OFF IMAGES training'
x_training = xy_training[:,-1:].copy()
y_training = xy_training[:,:-1].copy()
xy_training = None

print 'SPLIT OFF IMAGES cross'
x_cross = xy_cross[:,-1:].copy()
y_cross = xy_cross[:,:-1].copy()
xy_cross = None

print 'RESHAPE IMAGES'
x_training_full = np.array(list(x_training_full[:,0])) #Full Training Data
x_training = np.array(list(x_training[:,0]))  #Training Cut of Training Data
x_cross = np.array(list(x_cross[:,0])) #Cross Validation Cut of Training Data
x_test = np.array(list(x_test[:,0])) #TEST Set for final RMSQE score
#x_valid = np.array(list(x_valid[:])) #FINAL Visual Validation ZPICS

print 'SAVE TEST SETS'
np.save('../DATA/testX.npy', x_test)
np.save('../DATA/validX.npy', x_valid)
x_test = None
x_valid = None

print 'SAVE TRAINING INPUT DATA'
np.save('../DATA/fullX.npy', x_training_full)
np.save('../DATA/trainX.npy', x_training)
np.save('../DATA/crossX.npy', x_cross)
x_training_full = None
x_training = None
x_cross = None


EyesNoseLipCols = [0,1,2,3,20,21,28,29] 
RemainderCols = [4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,22,23,24,25,26,27]

print 'SPLIT TRAINING TARGET SETS BY FEATURE'
y_full_A = y_training_full[:,EyesNoseLipCols].copy()
y_full_B = y_training_full[:,RemainderCols].copy()
y_training_full = None

y_train_A = y_training[:,EyesNoseLipCols].copy()
y_train_B = y_training[:,RemainderCols].copy()
y_training = None

y_cross_A = y_cross[:,EyesNoseLipCols].copy()
y_cross_B = y_cross[:,RemainderCols].copy()
y_cross = None

print 'SAVING TARGET SETS'
np.save('../DATA/fullYa.npy', y_full_A)
np.save('../DATA/fullYb.npy', y_full_B)
np.save('../DATA/trainYa.npy', y_train_A)
np.save('../DATA/trainYb.npy', y_train_B)
np.save('../DATA/crossYa.npy', y_cross_A)
np.save('../DATA/crossYb.npy', y_cross_B)

print 'DONE'




