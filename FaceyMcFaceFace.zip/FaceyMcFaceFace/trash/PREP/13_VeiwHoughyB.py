import numpy as np
from PIL import Image
from math import floor
import  matplotlib.pyplot as pot
from matplotlib.lines import Line2D  

ACTY = (np.load('../DATA/A_Clean_Train_Y_HOT.npy')[1,:,:,2:4].copy() * 48).reshape((1,12,12,2))
Y = ((np.load('../DATA/A_Clean_Train_Y.npy')[1,2:4].reshape((1,2)) + 0.5 ) * 48.0)
X = np.load('../DATA/A_Clean_Train_X_SHRINK.npy')[1].reshape((1,48,48))

fig,plt = pot.subplots()
plt.imshow(X[0], cmap='Greys_r')
for x in range(12):
	for y in range(12):
		a = x * 4
		b = y * 4
		c = a + ACTY[0,x,y,0]
		d = b + ACTY[0,x,y,1]
		print a,b,c,d
		plt.plot([a,c,a],[b,d,b],'k-',lw=2)
pt = pot.Circle((Y[0,0], Y[0,1] ), 2, color='b', fill=False)
plt.add_artist(pt)
plt.autoscale(True)
pot.show()	



