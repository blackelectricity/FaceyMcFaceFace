import sys
sys.path.insert(0, '../../HELPER')
import IMSHOW

import tensorflow as tf
import numpy as np

XO = np.load('../../DATA/Xval.npy')
XV = np.load('../../../DEEPFACE/DATA/XvalSHRINK.npy')
YV = np.load('../../DATA/Yval.npy')

with tf.device('/gpu:0'):
	x  = tf.placeholder(tf.float32, shape=[ None, 48*48 ])
	
	weight_matrix = []
	bias_matrix = []
	full_matrix = []
	
	index = -1


	def loadModel():
		global index
		global bias_matrix
		global weight_matrix
		index += 1
		w = np.load('../MODEL/w' + str(index) + '.npy')
		waity = tf.constant(w, shape=list(w.shape))
		b = np.load('../MODEL/b' + str(index) + '.npy')
		biasy = tf.constant(b, shape=list(b.shape)) 
		weight_matrix.append(waity)
		bias_matrix.append(biasy)

	def tanconv(logit,shapeypoo,nummy):
		x = tf.nn.conv2d(logit,weight_matrix[nummy],strides=shapeypoo,padding='SAME')  
		x = tf.add(x, bias_matrix[nummy])
		return tf.nn.tanh(x)


	#FULLY CONNECTED LAYERS
	for i in range(0,3):
		loadModel()

	fulls = len(weight_matrix)  
	full_matrix.append(x)
	for i in range(fulls-1):
		mm = tf.matmul( full_matrix[i], weight_matrix[i] )
		hv = tf.nn.tanh( mm + bias_matrix[i])
		full_matrix.append(hv)

	#LAST LAYER NEVER DROPOUT 
	i = fulls-1		
	mm = tf.matmul( full_matrix[i], weight_matrix[i] )
	y_ = tf.nn.tanh( mm + bias_matrix[i] )
	
	init = tf.initialize_all_variables()

sess = tf.Session(config=tf.ConfigProto(allow_soft_placement=True))
sess.run(init)

(YV_) = sess.run([y_], feed_dict={ x: XV })
print len(YV_)

for i in range(0,10):
	IMSHOW.ShowWithDoubleFeature(XO[i], YV[i], YV_[0][i])

print 'afinit'
sess.close()
print 'finito'
	
